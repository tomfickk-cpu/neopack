$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot

Write-Host "╔══════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  NeoPack ENTERPRISE v3.0.0 Setup    ║" -ForegroundColor Cyan
Write-Host "║  169 Agents · 14 MCPs · 1 clique    ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════╝" -ForegroundColor Cyan

try { $v = node --version; Write-Host "`n[1/4] Node.js $v OK" -ForegroundColor Green }
catch { Write-Host "Instale Node.js em https://nodejs.org" -ForegroundColor Red; exit 1 }

Write-Host "[2/4] Instalando OpenCode CLI..." -ForegroundColor Yellow
npm install -g @opencode/cli 2>$null

Write-Host "[3/4] Copiando configuracoes..." -ForegroundColor Yellow
$ConfigDir = "$env:USERPROFILE\.config\opencode"
New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null
New-Item -ItemType Directory -Path "$env:USERPROFILE\NeoPack" -Force | Out-Null
Copy-Item "$Root\config\opencode.jsonc" "$ConfigDir\opencode.jsonc" -Force
Copy-Item "$Root\.opencode" "$env:USERPROFILE\NeoPack\" -Recurse -Force

Write-Host "[4/4] Finalizado!" -ForegroundColor Green
Write-Host "`n╔══════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║  NeoPack ENTERPRISE instalado!      ║" -ForegroundColor Green
Write-Host "║  cd ~/NeoPack                       ║" -ForegroundColor White
Write-Host "║  opencode                           ║" -ForegroundColor White
Write-Host "╚══════════════════════════════════════╝" -ForegroundColor Green
