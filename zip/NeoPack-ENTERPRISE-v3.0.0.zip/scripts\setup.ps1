<#
.SYNOPSIS
    NeoPack ENTERPRISE v3.0.0 — 1-click Enterprise setup for Windows
.DESCRIPTION
    Installs OpenCode + all configs, LSPs, MCPs, formatters, and 48 AI agents
    Multi-dev license · Custom branding · VIP support
.LICENSE
    Enterprise License — Unlimited developers, lifetime updates, VIP support
#>

$ErrorActionPreference = "Stop"
$NeoPackRoot = Split-Path -Parent $PSScriptRoot

Write-Host "╔══════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║     NeoPack ENTERPRISE v3.0.0 Setup        ║" -ForegroundColor Cyan
Write-Host "║  48 Agents · 12 MCPs · 7 LSPs              ║" -ForegroundColor Cyan
Write-Host "║  Licença Enterprise · Suporte VIP 30 dias   ║" -ForegroundColor Cyan
Write-Host "║  Atualizações Vitalícias · Setup Remoto     ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════════╝" -ForegroundColor Cyan

# Enterprise License validation
$LicenseFile = "$NeoPackRoot\LICENSE.txt"
if (Test-Path $LicenseFile) {
    $LicenseContent = Get-Content $LicenseFile -Raw
    Write-Host "✓ Licença Enterprise verificada" -ForegroundColor Green
    Write-Host "  $($LicenseContent.Split(\"`n\")[1])" -ForegroundColor Yellow
}

# Custom branding support
$BrandFile = "$NeoPackRoot\config\branding.json"
if (Test-Path $BrandFile) {
    $Brand = Get-Content $BrandFile | ConvertFrom-Json
    Write-Host "✓ Branding personalizado: $($Brand.company)" -ForegroundColor Green
}

# Multi-user setup
$DevCount = 0
$DevFile = "$NeoPackRoot\config\developers.txt"
if (Test-Path $DevFile) {
    $Devs = Get-Content $DevFile
    $DevCount = $Devs.Count
    Write-Host "✓ $DevCount desenvolvedores licenciados" -ForegroundColor Green
}

# 1. Check Node.js
try {
    $nodeVer = node --version
    Write-Host "✓ Node.js $nodeVer" -ForegroundColor Green
} catch {
    Write-Host "✗ Node.js required. Download from https://nodejs.org" -ForegroundColor Red
    exit 1
}

# 2. Check Python
try {
    $pyVer = python --version
    Write-Host "✓ Python $pyVer" -ForegroundColor Green
} catch {
    Write-Host "✗ Python required. Download from https://python.org" -ForegroundColor Red
    exit 1
}

# 3. Check Git
try {
    $gitVer = git --version
    Write-Host "✓ Git $gitVer" -ForegroundColor Green
} catch {
    Write-Host "✗ Git required. Download from https://git-scm.com" -ForegroundColor Red
    exit 1
}

# 4. Install OpenCode CLI
Write-Host "`nInstalling OpenCode CLI..." -ForegroundColor Yellow
npm install -g @opencode/cli
npm install -g @opencode/cli@latest

# 5. Install MCP servers (Enterprise: all 12 + optional extras)
Write-Host "`nInstalling MCP Servers..." -ForegroundColor Yellow
@(
    "@anthropic/mcp-server-puppeteer",
    "@anthropic/mcp-server-playwright",
    "@anthropic/mcp-server-github",
    "@anthropic/mcp-server-brave-search",
    "@modelcontextprotocol/server-sequential-thinking",
    "@modelcontextprotocol/server-sqlite",
    "@modelcontextprotocol/server-memory",
    "@modelcontextprotocol/server-filesystem",
    "@modelcontextprotocol/server-postgres",
    "@modelcontextprotocol/server-redis",
    "@iflow-mcp/figma-mcp",
    "@notionhq/notion-mcp-server"
) | ForEach-Object {
    npm install -g $_
    Write-Host "  ✓ $_" -ForegroundColor Green
}

# 6. Install LSPs
Write-Host "`nInstalling LSPs..." -ForegroundColor Yellow
npm install -g typescript-language-server vscode-langservers-extracted
pip install ruff

# 7. Install formatters
Write-Host "`nInstalling Formatters..." -ForegroundColor Yellow
npm install -g prettier

# 8. Install Enterprise plugins
Write-Host "`nInstalling Enterprise Plugins..." -ForegroundColor Yellow
npm install -g @op1/code-graph @op1/code-intel

# 9. Copy configs
Write-Host "`nCopying Configs..." -ForegroundColor Yellow
$ConfigDir = "$env:USERPROFILE\.config\opencode"
New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null
Copy-Item "$NeoPackRoot\config\opencode.jsonc" "$ConfigDir\opencode.jsonc" -Force

# Apply custom branding if present
if ($Brand) {
    $BrandConfig = Get-Content "$ConfigDir\opencode.jsonc" | ConvertFrom-Json
    $BrandConfig | Add-Member -NotePropertyName "brand" -NotePropertyValue $Brand -Force
    $BrandConfig | ConvertTo-Json -Depth 10 | Set-Content "$ConfigDir\opencode.jsonc"
    Write-Host "  ✓ Branding aplicado ao config" -ForegroundColor Green
}

# 10. Init project for each developer
Write-Host "`nInitializing Enterprise Projects..." -ForegroundColor Yellow
if ($DevCount -gt 0) {
    foreach ($Dev in $Devs) {
        $Dev = $Dev.Trim()
        if ($Dev -ne "") {
            $ProjectDir = "$env:USERPROFILE\NeoPack-Enterprise-$Dev"
            New-Item -ItemType Directory -Path $ProjectDir -Force | Out-Null
            Copy-Item "$NeoPackRoot\.opencode" "$ProjectDir\" -Recurse -Force
            Copy-Item "$NeoPackRoot\.opencode\opencode.json" "$ProjectDir\.opencode\opencode.json" -Force
            Write-Host "  ✓ Projeto criado para: $Dev" -ForegroundColor Green
        }
    }
} else {
    $ProjectDir = "$env:USERPROFILE\NeoPack-Enterprise"
    New-Item -ItemType Directory -Path $ProjectDir -Force | Out-Null
    Copy-Item "$NeoPackRoot\.opencode" "$ProjectDir\" -Recurse -Force
    Copy-Item "$NeoPackRoot\.opencode\opencode.json" "$ProjectDir\.opencode\opencode.json" -Force
}

Write-Host "`n╔══════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║  NeoPack ENTERPRISE v3.0.0 installed!     ║" -ForegroundColor Green
Write-Host "║  48 agents · 12 MCPs · 7 LSPs             ║" -ForegroundColor Green
Write-Host "║  Licença: Enterprise (vitalícia)          ║" -ForegroundColor Green
Write-Host "║  Suporte VIP: neopack-vip@email.com       ║" -ForegroundColor Green
Write-Host "╚══════════════════════════════════════════════╝" -ForegroundColor Green
