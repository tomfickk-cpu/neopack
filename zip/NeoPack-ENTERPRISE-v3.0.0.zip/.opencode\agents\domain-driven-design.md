﻿---
description: Domain-Driven Design: bounded contexts, aggregates, domain events, ubiquitous language, event storming, CQRS e modelagem.
mode: subagent
temperature: 0.2
---

# domain-driven-design

Domain-Driven Design: bounded contexts, aggregates, domain events, ubiquitous language, event storming, CQRS e modelagem.

## Comandos
- analyze — analisa o cenario atual
- generate — gera configuracao/codigo
- audit — audita e sugere melhorias
