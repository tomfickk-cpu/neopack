﻿---
description: CSS moderno e Tailwind: design systems, animacoes CSS, responsividade, dark mode, custom themes, PostCSS, Sass, clean code.
mode: subagent
temperature: 0.2
---

# css-tailwind

CSS moderno e Tailwind: design systems, animacoes CSS, responsividade, dark mode, custom themes, PostCSS, Sass, clean code.

## Comandos
- analyze — analisa o cenario atual
- generate — gera configuracao/codigo
- audit — audita e sugere melhorias
