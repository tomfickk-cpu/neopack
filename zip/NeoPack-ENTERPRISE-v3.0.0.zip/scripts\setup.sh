#!/bin/bash
# NeoPack ENTERPRISE v3.0.0 — 1-click Enterprise setup for Linux (Ubuntu/Debian)
set -euo pipefail

NEO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "╔══════════════════════════════════════════════╗"
echo "║   NeoPack ENTERPRISE v3.0.0 Setup (Linux)  ║"
echo "║  48 Agents · 12 MCPs · 7 LSPs              ║"
echo "║  Enterprise License · VIP Support           ║"
echo "╚══════════════════════════════════════════════╝"

# Enterprise License check
if [ -f "$NEO_ROOT/LICENSE.txt" ]; then
    echo "✓ Enterprise License found"
fi

# Custom branding
BRAND_FILE="$NEO_ROOT/config/branding.json"
if [ -f "$BRAND_FILE" ]; then
    COMPANY=$(grep -o '"company": *"[^"]*"' "$BRAND_FILE" | cut -d'"' -f4)
    echo "✓ Branding: $COMPANY"
fi

# 1. Node.js
if ! command -v node &>/dev/null; then
    echo "Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi
echo "✓ Node.js $(node --version)"

# 2. System deps
echo "Installing system dependencies..."
apt-get update
apt-get install -y git curl wget python3 python3-pip golang-go

# 3. OpenCode CLI
echo "Installing OpenCode CLI..."
npm install -g @opencode/cli @opencode/cli@latest

# 4. MCP Servers (Enterprise: all 12)
echo "Installing MCP Servers..."
MCP_PACKAGES=(
    "@anthropic/mcp-server-puppeteer"
    "@anthropic/mcp-server-playwright"
    "@anthropic/mcp-server-github"
    "@anthropic/mcp-server-brave-search"
    "@modelcontextprotocol/server-sequential-thinking"
    "@modelcontextprotocol/server-sqlite"
    "@modelcontextprotocol/server-memory"
    "@modelcontextprotocol/server-filesystem"
    "@modelcontextprotocol/server-postgres"
    "@modelcontextprotocol/server-redis"
    "@iflow-mcp/figma-mcp"
    "@notionhq/notion-mcp-server"
)
for pkg in "${MCP_PACKAGES[@]}"; do
    npm install -g "$pkg"
    echo "  ✓ $pkg"
done

# 5. LSPs
echo "Installing LSPs..."
npm install -g typescript-language-server vscode-langservers-extracted
pip3 install ruff

# 6. Formatters
echo "Installing Formatters..."
npm install -g prettier

# 7. Go tools
go install golang.org/x/tools/gopls@latest

# 8. Copy configs
echo "Copying configs..."
CONFIG_DIR="$HOME/.config/opencode"
mkdir -p "$CONFIG_DIR"
cp "$NEO_ROOT/config/opencode.jsonc" "$CONFIG_DIR/opencode.jsonc"

# 9. Multi-developer project setup
echo "Initializing Enterprise projects..."
DEVS_FILE="$NEO_ROOT/config/developers.txt"
if [ -f "$DEVS_FILE" ]; then
    while IFS= read -r dev; do
        [ -z "$dev" ] || [[ "$dev" == \#* ]] && continue
        PROJECT_DIR="$HOME/NeoPack-Enterprise-$dev"
        mkdir -p "$PROJECT_DIR/.opencode"
        cp -r "$NEO_ROOT/.opencode/agents" "$PROJECT_DIR/.opencode/"
        cp "$NEO_ROOT/.opencode/opencode.json" "$PROJECT_DIR/.opencode/opencode.json"
        echo "  ✓ Project created for: $dev"
    done < "$DEVS_FILE"
else
    PROJECT_DIR="$HOME/NeoPack-Enterprise"
    mkdir -p "$PROJECT_DIR/.opencode"
    cp -r "$NEO_ROOT/.opencode/agents" "$PROJECT_DIR/.opencode/"
    cp "$NEO_ROOT/.opencode/opencode.json" "$PROJECT_DIR/.opencode/opencode.json"
fi

# 10. Install Playwright browsers
npx playwright install chromium 2>/dev/null || true

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  NeoPack ENTERPRISE v3.0.0 installed!     ║"
echo "║  cd ~/NeoPack-Enterprise                    ║"
echo "║  opencode                                   ║"
echo "╚══════════════════════════════════════════════╝"
