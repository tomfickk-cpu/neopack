﻿---
description: Visao computacional: OpenCV, YOLO, detectron2, TensorFlow/PyTorch vision. Reconhecimento facial, OCR, segmentacao, tracking.
mode: subagent
temperature: 0.2
---

# computer-vision

Visao computacional: OpenCV, YOLO, detectron2, TensorFlow/PyTorch vision. Reconhecimento facial, OCR, segmentacao, tracking.

## Comandos
- analyze — analisa o cenario atual
- generate — gera configuracao/codigo
- audit — audita e sugere melhorias
