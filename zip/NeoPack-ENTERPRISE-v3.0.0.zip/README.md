﻿# NeoPack ENTERPRISE v3.0.0

**Licença Enterprise** — Unlimited developers · Lifetime updates · VIP Support · Consultoria mensal · Treinamento

## 🔥 Diferenciais Enterprise

| Recurso | PRO | ENTERPRISE |
|---------|-----|------------|
| Agentes | 48 | 48 |
| MCPs | 12 | 12 |
| LSPs + Formatters | 7+3 | 7+3 |
| Desenvolvedores | 1 | **Ilimitados** |
| Máquinas | 3 | **Ilimitadas** |
| Atualizações | 3 meses | **Vitalícias** |
| Suporte | 7 dias e-mail | **VIP 30 dias** |
| Setup Remoto | ❌ | **Treinamento ao vivo 2h** |
| Branding Personalizado | ❌ | **✓** |
| Agentes Customizados | ❌ | **Até 10** |
| Canal Privado Telegram/Discord | ❌ | **✓** |
| Acesso Antecipado Beta | ❌ | **✓** |
| Pipeline CI/CD Personalizado | ❌ | **✓** |
| Relatórios Mensais | ❌ | **✓** |
| Consultoria Mensal | ❌ | **1h dedicada** |
| Certificado Parceiro Oficial | ❌ | **✓** |
| SLA Resposta | 48h | **4h úteis** |
| Multi-projeto automático | ❌ | **✓** |
| Staging Gerenciado | ❌ | **✓** |
| Integração Sistemas Legados | ❌ | **✓** |
| Backup Automático Configs | ❌ | **✓** |
| Namespace Empresarial | ❌ | **✓** |

## 🚀 Instalação

**Windows (como Administrador):**
`powershell
.\scripts\setup.ps1
`

**Linux/macOS:**
`ash
chmod +x scripts/setup.sh && ./scripts/setup.sh
`

## 🎨 Branding Personalizado

Edite config/branding.json com os dados da sua empresa:

`json
{
  "company": "Minha Empresa Ltda",
  "logo": "caminho/logo.png",
  "theme": { "primary": "#00ff41", "secondary": "#b000ff" }
}
`

## 👥 Multi-Developer

Edite config/developers.txt com os nomes dos devs.
O setup criará projetos individuais para cada um.

## 📞 Suporte VIP
- Canal privado: Telegram/Discord direto com equipe
- E-mail: neopack-vip@email.com
- SLA: 4h úteis
- Agendamento remoto: 48h
- Consultoria mensal: 1h dedicada

## 🏆 Benefícios Exclusivos
- Pipeline CI/CD personalizado pré-configurado
- Relatórios mensais de desempenho dos agentes
- Acesso antecipado beta a novos agentes e MCPs
- Ambiente de staging gerenciado
- Backup e restore automático de configurações
- Namespace empresarial dedicado
- Garantia de compatibilidade estendida

© 2026 NeoPack. Todos os direitos reservados.
