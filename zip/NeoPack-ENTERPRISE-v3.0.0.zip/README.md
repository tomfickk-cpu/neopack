# NeoPack ENTERPRISE v3.0.0

**Licença Enterprise** — Unlimited developers · Lifetime updates · VIP Support

## 🔥 Diferenciais Enterprise

| Recurso | PRO | ENTERPRISE |
|---------|-----|------------|
| Agentes | 48 | 48 |
| MCPs | 12 | 12 |
| LSPs + Formatters | 7+3 | 7+3 |
| Desenvolvedores | 1 | Ilimitados |
| Máquinas | 3 | Ilimitadas |
| Atualizações | 3 meses | **Vitalícias** |
| Suporte | 7 dias e-mail | **VIP 30 dias** |
| Setup Remoto | ❌ | **2 sessões** |
| Branding Personalizado | ❌ | **✓** |
| Agentes Customizados | ❌ | **Até 5** |
| Multi-projeto automático | ❌ | **✓** |

## 🚀 Instalação

**Windows (como Administrador):**
```powershell
.\scripts\setup.ps1
```

**Linux/macOS:**
```bash
chmod +x scripts/setup.sh && ./scripts/setup.sh
```

## 🎨 Branding Personalizado

Edite `config/branding.json` com os dados da sua empresa:

```json
{
  "company": "Minha Empresa Ltda",
  "theme": { "primary": "#00ff41" }
}
```

## 👥 Multi-Developer

Edite `config/developers.txt` com os nomes dos devs.
O setup criará projetos individuais para cada um.

## 📞 Suporte VIP
- E-mail: neopack-vip@email.com
- SLA: 4h úteis
- Agendamento remoto: 48h

© 2026 NeoPack. Todos os direitos reservados.
