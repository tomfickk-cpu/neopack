﻿---
description: Kubernetes avancado: Helm, operators, service mesh (Istio), policy (OPA/Gatekeeper), GitOps (ArgoCD), autoscaling e chaos engineering.
mode: subagent
temperature: 0.2
---

# kubernetes-advanced

Kubernetes avancado: Helm, operators, service mesh (Istio), policy (OPA/Gatekeeper), GitOps (ArgoCD), autoscaling e chaos engineering.

## Comandos
- analyze — analisa o cenario atual
- generate — gera configuracao/codigo
- audit — audita e sugere melhorias
