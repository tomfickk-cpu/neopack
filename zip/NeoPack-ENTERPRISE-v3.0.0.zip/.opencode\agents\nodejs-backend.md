﻿---
description: Backend Node.js/TypeScript: Express, NestJS, Fastify, Prisma, tRPC, GraphQL, microservicos, autenticacao JWT/OAuth e APIs REST.
mode: subagent
temperature: 0.2
---

# nodejs-backend

Backend Node.js/TypeScript: Express, NestJS, Fastify, Prisma, tRPC, GraphQL, microservicos, autenticacao JWT/OAuth e APIs REST.

## Comandos
- analyze — analisa o cenario atual
- generate — gera configuracao/codigo
- audit — audita e sugere melhorias
