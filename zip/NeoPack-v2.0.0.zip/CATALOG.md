# 📦 NeoPack v2.0.0 — Catálogo Completo

## 🤖 Agentes (36)

| # | Agente | Descrição |
|---|--------|-----------|
| 1 | **explore** | Busca rápida em codebase (grep/glob) |
| 2 | **build-assistant** | Build, lint, typecheck, documentação |
| 3 | **web-dev** | HTML/CSS/JS — DOM, Flexbox, Grid, responsivo |
| 4 | **image-processor** | Processamento e validação de imagens |
| 5 | **content-mapper** | Mapeamento e sincronização de conteúdo |
| 6 | **go-dev** | Desenvolvimento Go (compilação, testes, LSP) |
| 7 | **seo-qa** | SEO, acessibilidade, performance, testes visuais |
| 8 | **db-agent** | SQLite — tabelas, consultas, relatórios |
| 9 | **pdf-processor** | Extração e processamento de PDFs |
| 10 | **code-review** | Revisão de código (qualidade, segurança, perf) |
| 11 | **data-pipeline** | Pipeline de dados (CSV, JSON, Excel, SQLite) |
| 12 | **script-automation** | Automação (Python, Batch, PowerShell) |
| 13 | **general** | Propósito geral — pesquisa e multi-step tasks |
| 14 | **customize-opencode** | Configuração do OpenCode |
| 15 | **cudf-agent** | GPU DataFrame (cuDF) — pandas em GPU |
| 16 | **cuopt-agent** | Otimização com cuOpt (GPU) |
| 17 | **cuda-q-agent** | Computação quântica com CUDA-Q |
| 18 | **cupynumeric-agent** | NumPy-like em GPU com cuPyNumeric |
| 19 | **optimization-concepts** | Conceitos de otimização (LP, MILP, QUBO) |
| 20 | **portfolio-optimizer** | Mean-CVaR, fronteira eficiente, backtest |
| 21 | **cutile-agent** | GPU kernels tile-based com cuTile |
| 22 | **tilegym-hf** | TileGym + Hugging Face Transformers |
| 23 | **cutile-optimizer** | Otimização iterativa de kernels cuTile |
| 24 | **cutile-autotune** | Autotuning CuTile (exhaustive_search, hints_fn) |
| 25 | **cutile-to-triton** | Conversor cuTile → Triton |
| 26 | **cutile-py2jl** | Conversor cuTile Python → Julia |
| 27 | **cutile-pareto** | Fronteira de Pareto com cuOpt |
| 28 | **bsp-promote** | Promover overlays/artefatos para BSP image |
| 29 | **jetson-dram-reclaim** | Reclaim DRAM em Jetson (MB1/MB2/DT/SWIOTLB) |
| 30 | **jetson-headless-memory** | Reclaim memória GUI/daemons em Jetson |
| 31 | **jetson-mgbe-qsfp** | MGBE QSFP 25G/10G/1G via DT overlay |
| 32 | **jetson-clock-lock** | Lock/cap clocks CPU/GPU/EMC via BPMP DTB |
| 33 | **tao-gpu-host** | Host setup para TAO (driver 580, CUDA 13.0) |
| 34 | **tao-k8s** | TAO jobs como k8s Jobs com GPU |
| 35 | **brev-tao** | Brev GPU instances para TAO |
| 36 | **brev-nemo-rl** | Brev + NeMo-RL com /ephemeral volume |

## 🔌 MCP Servers (8)

| Server | Descrição |
|--------|-----------|
| Puppeteer | Automação de browser headless |
| Playwright | Automação cross-browser |
| GitHub | API do GitHub (PRs, issues, repositórios) |
| Brave Search | Pesquisa web |
| Sequential Thinking | Raciocínio estruturado |
| SQLite | Banco de dados SQLite |
| Memory | Grafo de conhecimento persistente |
| Filesystem | Acesso ao sistema de arquivos |

## 🎯 LSPs (7)

Go (gopls), TypeScript, HTML, CSS, JSON, Python (ruff), Markdown

## ✨ Formatters (3)

Go (gofmt), Prettier, Python (ruff)

## 🔧 Plugins (2)

@op1/code-graph, @op1/code-intel

## 🖥️ Plataformas (7)

Windows, Ubuntu/Debian, RHEL/Fedora, macOS, Docker, Dev Container, GitHub Codespaces
