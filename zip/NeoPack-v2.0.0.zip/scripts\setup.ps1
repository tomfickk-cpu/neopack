<#
.SYNOPSIS
    NeoPack v2.0.0 — 1-click setup for Windows
.DESCRIPTION
    Installs OpenCode + all configs, LSPs, MCPs, formatters, and 36 AI agents
#>

$ErrorActionPreference = "Stop"
$NeoPackRoot = Split-Path -Parent $PSScriptRoot

Write-Host "╔══════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║      NeoPack v2.0.0 Setup (Win)     ║" -ForegroundColor Cyan
Write-Host "║  36 Agents · 8 MCPs · 7 LSPs · 3 Fmt ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════╝" -ForegroundColor Cyan

# 1. Check Node.js
try {
    $nodeVer = node --version
    Write-Host "✓ Node.js $nodeVer" -ForegroundColor Green
} catch {
    Write-Host "✗ Node.js required. Download from https://nodejs.org" -ForegroundColor Red
    exit 1
}

# 2. Install OpenCode CLI
Write-Host "`nInstalling OpenCode CLI..." -ForegroundColor Yellow
npm install -g @opencode/cli

# 3. Install MCP servers
Write-Host "`nInstalling MCP Servers..." -ForegroundColor Yellow
@(
    "@anthropic/mcp-server-puppeteer",
    "@anthropic/mcp-server-playwright",
    "@anthropic/mcp-server-github",
    "@anthropic/mcp-server-brave-search",
    "@modelcontextprotocol/server-sequential-thinking",
    "@modelcontextprotocol/server-sqlite",
    "@modelcontextprotocol/server-memory",
    "@modelcontextprotocol/server-filesystem"
) | ForEach-Object {
    npm install -g $_
    Write-Host "  ✓ $_" -ForegroundColor Green
}

# 4. Install LSPs
Write-Host "`nInstalling LSPs..." -ForegroundColor Yellow
npm install -g typescript-language-server vscode-langservers-extracted
pip install ruff

# 5. Install formatters
Write-Host "`nInstalling Formatters..." -ForegroundColor Yellow
npm install -g prettier

# 6. Copy configs
Write-Host "`nCopying Configs..." -ForegroundColor Yellow
$ConfigDir = "$env:USERPROFILE\.config\opencode"
New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null
Copy-Item "$NeoPackRoot\config\opencode.jsonc" "$ConfigDir\opencode.jsonc" -Force

# 7. Init project
Write-Host "`nInitializing NeoPack Project..." -ForegroundColor Yellow
$ProjectDir = "$env:USERPROFILE\NeoPack"
New-Item -ItemType Directory -Path $ProjectDir -Force | Out-Null
Copy-Item "$NeoPackRoot\.opencode" "$ProjectDir\" -Recurse -Force
Copy-Item "$NeoPackRoot\.opencode\opencode.json" "$ProjectDir\.opencode\opencode.json" -Force

Write-Host "`n╔══════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║  NeoPack v2.0.0 installed!          ║" -ForegroundColor Green
Write-Host "║  cd ~\NeoPack                       ║" -ForegroundColor Green
Write-Host "║  opencode                           ║" -ForegroundColor Green
Write-Host "╚══════════════════════════════════════╝" -ForegroundColor Green
