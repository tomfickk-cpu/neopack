$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot

Write-Host "╔══════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║      NeoPack v3.0.0 Setup (Win)     ║" -ForegroundColor Cyan
Write-Host "║  33 Agents · OpenCode · 1 clique    ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════╝" -ForegroundColor Cyan

# 1. Check Node.js
try { $v = node --version; Write-Host "`n[1/4] Node.js $v OK" -ForegroundColor Green }
catch { Write-Host "Instale Node.js em https://nodejs.org e rode este script novamente." -ForegroundColor Red; exit 1 }

# 2. Install OpenCode
Write-Host "[2/4] Instalando OpenCode CLI..." -ForegroundColor Yellow
npm install -g @opencode/cli 2>$null
Write-Host "      OpenCode instalado!" -ForegroundColor Green

# 3. Copy configs
Write-Host "[3/4] Copiando configuracoes..." -ForegroundColor Yellow
$ConfigDir = "$env:USERPROFILE\.config\opencode"
New-Item -ItemType Directory -Path $ConfigDir -Force, "$env:USERPROFILE\NeoPack" -Force | Out-Null
Copy-Item "$Root\config\opencode.jsonc" "$ConfigDir\opencode.jsonc" -Force
Copy-Item "$Root\.opencode" "$env:USERPROFILE\NeoPack\" -Recurse -Force

# 4. Done
Write-Host "[4/4] Finalizado!" -ForegroundColor Green
Write-Host "`n╔══════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║  NeoPack v3.0.0 instalado!          ║" -ForegroundColor Green
Write-Host "║                                      ║" -ForegroundColor Green
Write-Host "║  cd ~/NeoPack                       ║" -ForegroundColor White
Write-Host "║  opencode                           ║" -ForegroundColor White
Write-Host "╚══════════════════════════════════════╝" -ForegroundColor Green
