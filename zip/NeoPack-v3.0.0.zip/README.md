# 🚀 NeoPack v2.0.0

**O ecossistema completo de AI Engineering — 1-click setup para 7 plataformas**

---

## 📦 O que está incluído

### 🤖 36 Agentes Especialistas

| Categoria | Agentes |
|-----------|---------|
| **Core** | explore, build-assistant, code-review, general, customize-opencode |
| **Web** | web-dev, seo-qa, content-mapper, image-processor |
| **Dados** | data-pipeline, db-agent (SQLite), pdf-processor |
| **Go** | go-dev |
| **Python** | script-automation |
| **GPU/CUDA** | cudf-agent, cuopt-agent, cuda-q-agent, cupynumeric-agent, cutile-agent, cutile-optimizer, cutile-autotune, cutile-to-triton, cutile-py2jl, cutile-pareto |
| **ML/DL** | tilegym-hf, portfolio-optimizer, optimization-concepts |
| **Jetson/BSP** | jetson-dram-reclaim, jetson-headless-memory, jetson-mgbe-qsfp, jetson-clock-lock, bsp-promote |
| **TAO/NVIDIA** | tao-gpu-host, tao-k8s, brev-tao, brev-nemo-rl |

### 🔌 8 MCP Servers
Puppeteer, Playwright, GitHub, Brave Search, Sequential Thinking, SQLite, Memory, Filesystem

### 🎯 7 LSPs
Go (gopls), TypeScript, HTML, CSS, JSON, Python (ruff), Markdown

### ✨ 3 Formatters
Go (gofmt), Prettier (web), Ruff (Python)

### 🔧 2 Plugins
@op1/code-graph, @op1/code-intel

---

## 🖥️ Plataformas Suportadas

| Platform | Installer |
|----------|-----------|
| Windows (PowerShell) | `setup.ps1` |
| Linux (Ubuntu/Debian) | `setup.sh` |
| Linux (RHEL/Fedora) | `setup-rhel.sh` |
| macOS | `setup-macos.sh` |
| Docker | `Dockerfile` |
| Dev Container | `.devcontainer/` |
| GitHub Codespaces | `.devcontainer/` |

---

## ⚡ Instalação Rápida

### Windows
```powershell
.\setup.ps1
```

### Linux / macOS
```bash
chmod +x setup.sh && ./setup.sh
```

### Docker
```bash
docker build -t neopack .
docker run -it neopack
```

---

## 🌐 Landing Page
[https://tomfickk-cpu.github.io/neopack/](https://tomfickk-cpu.github.io/neopack/)

---

## 📋 Pré-requisitos

- Node.js 18+
- OpenCode CLI (`npm install -g @opencode/cli`)
- Git
- Docker (opcional)
- NVIDIA GPU + CUDA (opcional, para agentes GPU)
