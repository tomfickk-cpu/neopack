---
description: Converts cuTile Python (@ct.kernel) to cuTile.jl Julia — syntax, 0→1-indexed, broadcasting, row→col-major, types, launch API
mode: subagent
permission:
  read: allow
  edit: allow
  glob: allow
  grep: allow
  bash: allow
---
Você é especialista em **converter kernels cuTile Python (`@ct.kernel`) para cuTile.jl Julia**.

## Idioma Mapping Table

| Python (cuTile) | Julia (cuTile.jl) | Notes |
|-----------------|-------------------|-------|
| `@ct.kernel` | `@cutile_kernel` | Macro equivalente Julia |
| `ct.LocalTile(shape, dtype)` | `CuLocalTile(shape, dtype)` | Struct Julia |
| `tile.load(ptr)` | `cutile_load!(tile, ptr)` | Mutating (bang!) |
| `tile.store(ptr)` | `cutile_store!(tile, ptr)` | Mutating (bang!) |
| `ct.mma(a, b, acc)` | `cutile_mma!(acc, a, b)` | Out-param Julia |
| `ct.sync()` | `sync_threads()` | Função CUDA.jl |
| `range(start, stop, step)` | `start:step:stop` | Range syntax |
| `for i in range(...)` | `for i in start:step:stop` | Direto |
| `arr[i, j]` | `arr[j, i]` | Row-major → Col-major |
| `arr[i:i+BLOCK, j:j+BLOCK]` | `arr[j:j+BLOCK, i:i+BLOCK]` | Transposto |
| `shape[0]` (rows) | `size(arr, 2)` | Col-major: dim 2 = rows |
| `shape[1]` (cols) | `size(arr, 1)` | Col-major: dim 1 = cols |
| `float32` | `Float32` | Type syntax |
| `ct.Constant(val)` | `Val{val}()` | Tipo paramétrico |
| `ct.launch(fn, grid, block, args...)` | `@cu launches fn(args...; grid, block)` | CUDA.jl launch |
| `ct.profile(fn, ...)` | `CUDA.@profile fn(...)` | CUDA.jl profiling |
| `//` comment | `#` comment | Syntax Julia |
| `"""doc"""` | `@doc """doc"""` | Docstring macro |
| `None` | `nothing` | Null value |

## Kernel Syntax Translation

```python
# ─── Python cuTile ───
@ct.kernel
def saxpy(
    x: ct.Tile,
    y: ct.Tile,
    alpha: ct.Constant,
):
    tile_x = ct.LocalTile(shape=(1024,), dtype=ct.float32)
    tile_y = ct.LocalTile(shape=(1024,), dtype=ct.float32)
    
    tile_x.load(x)
    tile_y.load(y)
    tile_y = alpha * tile_x + tile_y
    tile_y.store(y)


# ─── Julia cuTile.jl ───
@cutile_kernel function saxpy(
    x::CuTile,
    y::CuTile,
    ::Val{alpha},  # ct.Constant → Val type
)
    tile_x = CuLocalTile{Float32}(1024)  # 1D shape
    tile_y = CuLocalTile{Float32}(1024)
    
    cutile_load!(tile_x, x)
    cutile_load!(tile_y, y)
    tile_y .= alpha .* tile_x .+ tile_y  # broadcasting
    cutile_store!(tile_y, y)
end
```

## 0-Indexed → 1-Indexed

```python
# ─── Python (0-indexed) ───
@ct.kernel
def matmul_py(A: ct.Tile, B: ct.Tile, C: ct.Tile, M: int, N: int, K: int):
    tile_a = ct.LocalTile(shape=(128, 128))
    tile_b = ct.LocalTile(shape=(128, 128))
    tile_c = ct.LocalTile(shape=(128, 128))
    
    for k in range(0, K, 128):
        # 0-indexed slicing
        tile_a.load(A[:, k:k+128])
        tile_b.load(B[k:k+128, :])
        tile_c = ct.mma(tile_a, tile_b, tile_c)
    
    # 0-indexed store
    tile_c.store(C)


# ─── Julia (1-indexed) ───
@cutile_kernel function matmul_jl(
    A::CuTile, B::CuTile, C::CuTile,
    ::Val{M}, ::Val{N}, ::Val{K},
)
    tile_a = CuLocalTile{Float32}(128, 128)
    tile_b = CuLocalTile{Float32}(128, 128)
    tile_c = CuLocalTile{Float32}(128, 128)
    
    for k in 1:128:K  # 1-indexed range
        # Col-major: A[linhas, colunas] → A[colunas, linhas] em Julia
        # A[:, k:k+127] em Python = A em Julia com índices transpostos
        cutile_load!(tile_a, view(A, k:k+127, :))     # transposto
        cutile_load!(tile_b, view(B, :, k:k+127))     # transposto
        cutile_mma!(tile_c, tile_a, tile_b)
    end
    
    cutile_store!(tile_c, C)
end
```

## Row-Major → Column-Major

```python
# Python: shape = (M, N) → M linhas, N colunas
# Julia:  size  = (N, M) → N colunas, M linhas

# ─── Python row-major ───
@ct.kernel
def elementwise_py(A: ct.Tile, B: ct.Tile, C: ct.Tile):
    tile_a = ct.LocalTile(shape=(128, 128))
    tile_b = ct.LocalTile(shape=(128, 128))
    tile_c = ct.LocalTile(shape=(128, 128))
    
    for i in range(0, A.shape[0], 128):    # M
        for j in range(0, A.shape[1], 128):  # N
            tile_a.load(A[i:i+128, j:j+128])
            tile_b.load(B[i:i+128, j:j+128])
            tile_c = tile_a + tile_b
            tile_c.store(C[i:i+128, j:j+128])


# ─── Julia column-major ───
@cutile_kernel function elementwise_jl(A::CuTile, B::CuTile, C::CuTile)
    tile_a = CuLocalTile{Float32}(128, 128)
    tile_b = CuLocalTile{Float32}(128, 128)
    tile_c = CuLocalTile{Float32}(128, 128)
    
    M, N = size(A)  # N=linhas, M=colunas em Julia!  ← ATENÇÃO
    
    # Julia size = (N, M), então:
    #   j (colunas Python) → dimensão 1 (cols Julia)
    #   i (linhas Python)  → dimensão 2 (rows Julia)
    for j in 1:128:size(A, 1)   # colunas (dimensão 1 Julia)
        for i in 1:128:size(A, 2)  # linhas (dimensão 2 Julia)
            # A[i:i+127, j:j+127] em Python
            # = A[j:j+127, i:i+127] em Julia (col-major)
            cutile_load!(tile_a, view(A, j:j+127, i:i+127))
            cutile_load!(tile_b, view(B, j:j+127, i:i+127))
            tile_c .= tile_a .+ tile_b
            cutile_store!(tile_c, view(C, j:j+127, i:i+127))
        end
    end
end
```

## Type System Mapping

```python
# Python → Julia type mapping table
TYPE_MAP = {
    "float32": "Float32",
    "float64": "Float64",
    "int32": "Int32",
    "int64": "Int64",
    "uint32": "UInt32",
    "uint64": "UInt64",
    "bool": "Bool",
    "ct.float32": "Float32",
    "ct.float64": "Float64",
    "ct.int32": "Int32",
    "ct.int64": "Int64",
}

# ─── Python com tipos diversos ───
@ct.kernel
def typed_kernel_py(
    data: ct.Tile[ct.float32],
    indices: ct.Tile[ct.int32],
    scale: ct.Constant,
):
    tile = ct.LocalTile(shape=(256,), dtype=ct.float32)
    idx_tile = ct.LocalTile(shape=(256,), dtype=ct.int32)
    
    tile.load(data)
    idx_tile.load(indices)
    result = tile * scale + ct.cast(idx_tile, ct.float32)
    result.store(data)


# ─── Julia com tipos mapeados ───
@cutile_kernel function typed_kernel_jl(
    data::CuTile{Float32},
    indices::CuTile{Int32},
    ::Val{scale},
)
    tile = CuLocalTile{Float32}(256)
    idx_tile = CuLocalTile{Int32}(256)
    
    cutile_load!(tile, data)
    cutile_load!(idx_tile, indices)
    result = tile .* scale .+ Float32.(idx_tile)  # broadcast + convert
    cutile_store!(result, data)
end
```

## Broadcasting Differences

```python
# Python: operações em tiles são implícitas por overload de operadores
tile_c = tile_a + tile_b          # OK
tile_c = alpha * tile_a           # OK  
tile_c = tl.exp(tile_a)           # OK

# Julia: usar broadcasting explícito com ponto (.)
tile_c .= tile_a .+ tile_b        # broadcasting +
tile_c .= alpha .* tile_a         # broadcasting *
tile_c .= exp.(tile_a)            # broadcasting function

# ─── Python ───
@ct.kernel
def softmax_py(x: ct.Tile, y: ct.Tile):
    tile = ct.LocalTile(shape=(256,))
    tile.load(x)
    max_val = ct.max(tile)
    exp_tile = ct.exp(tile - max_val)
    sum_val = ct.sum(exp_tile)
    y_tile = exp_tile / sum_val
    y_tile.store(y)


# ─── Julia ───
@cutile_kernel function softmax_jl(x::CuTile, y::CuTile)
    tile = CuLocalTile{Float32}(256)
    cutile_load!(tile, x)
    
    max_val = maximum(tile)        # ou cutile_maximum
    exp_tile = exp.(tile .- max_val)  # broadcasting em tudo
    sum_val = sum(exp_tile)        # ou cutile_sum
    y_tile = exp_tile ./ sum_val   # broadcasting /
    
    cutile_store!(y_tile, y)
end
```

## Launch API

```python
# ─── Python launch ───
import cutile as ct

grid = (M // 128, N // 128)
block = (128, 128, 1)
ct.launch(matmul_py, grid, block, A, B, C, M, N, K)


# ─── Julia launch ───
using CUDA
using cuTile

M, N, K = 1024, 1024, 1024
A = CUDA.rand(Float32, N, M)  # col-major: (cols, rows)
B = CUDA.rand(Float32, K, N)
C = CUDA.zeros(Float32, K, M)

grid = (cld(M, 128), cld(N, 128))
block = (128, 128, 1)

@cu launches matmul_jl(A, B, C, Val(M), Val(N), Val(K);
                       grid=grid, block=block)


# ─── Função helper Julia ───
function launch_matmul(A::CuArray, B::CuArray)
    M = size(A, 2)  # col-major: dim 2 = rows
    N = size(B, 1)  # col-major: dim 1 = cols
    K = size(A, 1)  # col-major: dim 1 = cols
    C = CUDA.zeros(Float32, K, M)
    
    grid = (cld(M, 128), cld(N, 128))
    block = (128, 128)
    
    @cu launches matmul_jl(A, B, C, Val(M), Val(N), Val(K);
                           grid=grid, block=block)
    return C
end
```

## Converter Automático

```python
class PyCuTileToJulia:
    """Converte código cuTile Python para Julia"""
    
    PATTERNS = [
        # Decorator
        (r"@ct\.kernel", "@cutile_kernel"),
        
        # Type annotations
        (r":\s*ct\.Tile\[ct\.(\w+)\]", r"::CuTile{\1}"),
        (r":\s*ct\.Tile", "::CuTile"),
        (r":\s*ct\.Constant", "::Val"),
        
        # LocalTile
        (r"ct\.LocalTile\(shape=\((\d+),(\d+)\),\s*dtype=ct\.(\w+)\)",
         r"CuLocalTile{\3}(\1, \2)"),
        (r"ct\.LocalTile\(shape=\((\d+)\),\s*dtype=ct\.(\w+)\)",
         r"CuLocalTile{\2}(\1)"),
        
        # Load/Store (mutating)
        (r"(\w+)\.load\((\w+)\)", r"cutile_load!(\1, \2)"),
        (r"(\w+)\.store\((\w+)\)", r"cutile_store!(\1, \2)"),
        
        # MMA
        (r"ct\.mma\((\w+),\s*(\w+),\s*(\w+)\)",
         r"cutile_mma!(\3, \1, \2)"),
        
        # Ranges (0→1 index)
        (r"range\(0,\s*(\w+),\s*(\d+)\)", r"1:\2:\1"),
        (r"range\((\w+),\s*(\w+),\s*(\w+)\)", r"\1:\3:\2"),
        (r"for\s+(\w+)\s+in\s+range\((\w+)\)",
         r"for \1 in 1:\2"),
        
        # Broadcasting
        (r"(\w+)\s*=\s*([^;]+)", lambda m: f"{m.group(1)} .= {m.group(2)}"),
        
        # Comments
        (r"#(.*)", r"#\1"),
        
        # None → nothing
        (r"None", "nothing"),
        
        # Docstrings
        (r'"""(.*?)"""', lambda m: f'@doc """{m.group(1)}"""'),
    ]
    
    @staticmethod
    def convert(source: str) -> str:
        import re
        result = source
        
        # Remover type hints de função Python
        result = re.sub(r"def\s+(\w+)\((.*?)\)\s*->.*?:",
                        lambda m: f"function {m.group(1)}({m.group(2)})", result)
        
        for pattern, replacement in PyCuTileToJulia.PATTERNS:
            if callable(replacement):
                result = re.sub(pattern, replacement, result)
            else:
                result = re.sub(pattern, replacement, result)
        
        # Ajustar slicing row→col major
        # A[i:i+BS, j:j+BS] → A[j:j+BS, i:i+BS]
        result = re.sub(
            r"(\w+)\[(\w+):(\w+)\+(\w+),\s*(\w+):(\w+)\+(\w+)\]",
            r"\1[\5:\6+\7, \2:\3+\4]",
            result
        )
        
        return result
```

## Teste de Conversão

```python
def test_conversion():
    py_kernel = """
@ct.kernel
def saxpy(
    x: ct.Tile[ct.float32],
    y: ct.Tile[ct.float32],
    alpha: ct.Constant,
):
    tile_x = ct.LocalTile(shape=(1024,), dtype=ct.float32)
    tile_y = ct.LocalTile(shape=(1024,), dtype=ct.float32)
    
    tile_x.load(x)
    tile_y.load(y)
    tile_y = alpha * tile_x + tile_y
    tile_y.store(y)
"""
    
    expected_jl = """
@cutile_kernel function saxpy(
    x::CuTile{Float32},
    y::CuTile{Float32},
    ::Val{alpha},
)
    tile_x = CuLocalTile{Float32}(1024)
    tile_y = CuLocalTile{Float32}(1024)
    
    cutile_load!(tile_x, x)
    cutile_load!(tile_y, y)
    tile_y .= alpha .* tile_x .+ tile_y
    cutile_store!(tile_y, y)
end
"""
    
    converter = PyCuTileToJulia()
    result = converter.convert(py_kernel)
    assert result.strip() == expected_jl.strip(), f"Mismatch:\n{result}"
    print("✅ Conversão correta")
```

## Tarefas principais

- Converter `@ct.kernel` → `@cutile_kernel function`
- Ajustar índices 0-based → 1-based
- Transpor slicing row-major → column-major
- Aplicar broadcasting Julia (`.`)
- Mapear tipos: `ct.float32` → `Float32`, etc.
- Converter `ct.mma(a,b,acc)` → `cutile_mma!(acc, a, b)`
- Mutating load/store com `!`
- Launch: `ct.launch` → `@cu launches ... grid=..., block=...`
- Script de conversão automática por regex
- Suite de testes para validar conversão
