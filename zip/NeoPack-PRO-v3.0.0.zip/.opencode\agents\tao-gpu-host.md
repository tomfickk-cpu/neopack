---
description: Host setup for TAO GPU backends — check/install NVIDIA driver 580, CUDA 13.0, nvidia-container-toolkit 1.19.0. --check-only on any Linux
mode: subagent
permission:
  read: allow
  edit: allow
  glob: allow
  grep: allow
  bash: allow
---
Você é especialista em **host setup para TAO GPU backends** — NVIDIA driver 580, CUDA Toolkit 13.0, NVIDIA Container Toolkit 1.19.0 para Docker/Kubernetes.

## Arquitetura TAO GPU Backend

```
┌─────────────────────────────────────┐
│         TAO Toolkit (Docker)        │
├─────────────────────────────────────┤
│  nvidia-container-toolkit 1.19.0    │
├─────────────────────────────────────┤
│  NVIDIA Driver 580 (kernel module)  │
├─────────────────────────────────────┤
│  CUDA Toolkit 13.0 (userspace)      │
├─────────────────────────────────────┤
│  GPU Hardware (A100/H100/L40S/etc)  │
└─────────────────────────────────────┘
```

## Script Principal

```bash
#!/bin/bash
# tao-gpu-host-setup.sh
# Check/install NVIDIA driver 580, CUDA 13.0, nvidia-container-toolkit 1.19.0
# Uso: ./tao-gpu-host-setup.sh [--check-only] [--install] [--help]

set -euo pipefail

# ─── Config ───
DRIVER_BRANCH="580"
CUDA_VERSION="13.0"
CONTAINER_TOOLKIT_VERSION="1.19.0"
OS_ID=$(grep -oP '(?<=^ID=).+' /etc/os-release | tr -d '"' || echo "unknown")
OS_VERSION=$(grep -oP '(?<=^VERSION_ID=).+' /etc/os-release | tr -d '"' || echo "unknown")

# ─── Colors ───
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'
PASS="${GREEN}PASS${NC}"
FAIL="${RED}FAIL${NC}"
WARN="${YELLOW}WARN${NC}"

# ─── Check Functions ───
check_gpu() {
    echo ""
    echo "=== GPU Hardware ==="
    
    if ! command -v lspci &>/dev/null; then
        echo -e "  lspci: $FAIL (install pciutils)"
        return 1
    fi
    
    gpu_count=$(lspci -d 10de: 2>/dev/null | grep -c "3D controller\|VGA" || true)
    if [ "$gpu_count" -eq 0 ]; then
        echo -e "  NVIDIA GPUs: $FAIL (none detected)"
        return 1
    fi
    echo -e "  NVIDIA GPUs: $PASS ($gpu_count detected)"
    
    for gpu in $(lspci -d 10de: 2>/dev/null | grep "3D controller\|VGA" | awk '{print $1}'); do
        name=$(lspci -s "$gpu" | sed 's/.*: //')
        echo "    $gpu: $name"
    done
}

check_driver() {
    echo ""
    echo "=== NVIDIA Driver ==="
    
    if ! command -v nvidia-smi &>/dev/null; then
        echo -e "  nvidia-smi: $FAIL (driver not installed)"
        return 1
    fi
    
    driver_version=$(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null | head -1 || echo "unknown")
    driver_branch=$(echo "$driver_version" | cut -d. -f1)
    
    if [ "$driver_branch" = "$DRIVER_BRANCH" ]; then
        echo -e "  Driver version: $PASS ($driver_version, branch $DRIVER_BRANCH)"
    else
        echo -e "  Driver version: $FAIL ($driver_version, need branch $DRIVER_BRANCH)"
        return 1
    fi
    
    # Check persistence mode
    pers_mode=$(nvidia-smi --query-gpu=persistence_mode --format=csv,noheader 2>/dev/null | head -1 || echo "N/A")
    echo "  Persistence mode: $pers_mode"
}

check_cuda() {
    echo ""
    echo "=== CUDA Toolkit ==="
    
    if ! command -v nvcc &>/dev/null; then
        echo -e "  nvcc: $FAIL (CUDA Toolkit not installed)"
        return 1
    fi
    
    nvcc_version=$(nvcc --version 2>/dev/null | grep "release" | sed 's/.*release //;s/,.*//' || echo "unknown")
    
    if [ "$nvcc_version" = "$CUDA_VERSION" ]; then
        echo -e "  CUDA version: $PASS ($nvcc_version)"
    else
        echo -e "  CUDA version: $FAIL (found $nvcc_version, need $CUDA_VERSION)"
        return 1
    fi
    
    # Check CUDA libraries
    if ldconfig -p 2>/dev/null | grep -q "libcudart.so.$CUDA_VERSION"; then
        echo -e "  CUDA libraries: $PASS"
    else
        echo -e "  CUDA libraries: $WARN (not in ldconfig, check LD_LIBRARY_PATH)"
    fi
}

check_container_toolkit() {
    echo ""
    echo "=== NVIDIA Container Toolkit ==="
    
    if ! command -v nvidia-ctk &>/dev/null; then
        echo -e "  nvidia-ctk: $FAIL (not installed)"
        return 1
    fi
    
    ctk_version=$(nvidia-ctk --version 2>/dev/null | grep -oP '(?<=version )[\d.]+' || echo "unknown")
    
    if [ "$ctk_version" = "$CONTAINER_TOOLKIT_VERSION" ]; then
        echo -e "  Container Toolkit: $PASS ($ctk_version)"
    else
        echo -e "  Container Toolkit: $FAIL (found $ctk_version, need $CONTAINER_TOOLKIT_VERSION)"
        return 1
    fi
    
    # Check Docker runtime
    if docker info 2>/dev/null | grep -q "nvidia"; then
        echo -e "  Docker runtime: $PASS (nvidia)"
    else
        echo -e "  Docker runtime: $FAIL (nvidia runtime not configured)"
        return 1
    fi
    
    # Check containerd (Kubernetes)
    if command -v ctr &>/dev/null; then
        if ctr run --rm nvidia/cuda:12.0-base nvidia-smi 2>/dev/null; then
            echo -e "  containerd GPU: $PASS"
        else
            echo -e "  containerd GPU: $WARN (not tested)"
        fi
    fi
}

check_docker() {
    echo ""
    echo "=== Docker ==="
    
    if ! command -v docker &>/dev/null; then
        echo -e "  Docker: $FAIL (not installed)"
        return 1
    fi
    
    docker_version=$(docker --version | grep -oP '(?<=version )[\d.]+' || echo "unknown")
    echo -e "  Docker version: $docker_version"
    
    if docker run --rm --gpus all nvidia/cuda:12.0-base nvidia-smi &>/dev/null; then
        echo -e "  GPU passthrough: $PASS"
    else
        echo -e "  GPU passthrough: $FAIL"
        return 1
    fi
}

check_kubernetes() {
    echo ""
    echo "=== Kubernetes (optional) ==="
    
    if ! command -v kubectl &>/dev/null; then
        echo "  kubectl: not installed (skipping K8s checks)"
        return 0
    fi
    
    # Check node capacity
    gpu_capacity=$(kubectl get nodes -o json 2>/dev/null | \
        jq '.items[].status.capacity["nvidia.com/gpu"]' 2>/dev/null || echo "null")
    
    if [ "$gpu_capacity" != "null" ] && [ "$gpu_capacity" -gt 0 ] 2>/dev/null; then
        echo -e "  GPU capacity: $PASS ($gpu_capacity)"
    else
        echo -e "  GPU capacity: $WARN (nvidia.com/gpu not advertised)"
        echo "    Install NVIDIA k8s device plugin:"
        echo "    kubectl apply -f https://raw.githubusercontent.com/NVIDIA/k8s-device-plugin/v0.16.0/nvidia-device-plugin.yml"
    fi
    
    # Check gpu-operator
    if kubectl get pods -n nvidia-gpu-operator 2>/dev/null | grep -q "nvidia"; then
        echo -e "  GPU Operator: $PASS"
    fi
}

check_system() {
    echo ""
    echo "=== System =="
    
    # Kernel
    kernel=$(uname -r)
    echo "  Kernel: $kernel"
    
    # OS
    echo "  OS: $OS_ID $OS_VERSION"
    
    # Architecture
    arch=$(uname -m)
    echo "  Arch: $arch"
    
    # Memory
    mem=$(free -h | grep Mem | awk '{print $2}')
    echo "  Memory: $mem"
    
    # Disk
    disk=$(df -h / | tail -1 | awk '{print $4}')
    echo "  Free disk: $disk"
    
    # Nouveau check
    if lsmod | grep -q nouveau; then
        echo -e "  Nouveau: $FAIL (blacklist required)"
    else
        echo -e "  Nouveau: $PASS (blacklisted)"
    fi
    
    # Secure Boot
    if [ -d /sys/firmware/efi ] && command -v mokutil &>/dev/null; then
        sb_state=$(mokutil --sb-state 2>/dev/null || echo "unknown")
        echo "  Secure Boot: $sb_state"
        if echo "$sb_state" | grep -q "enabled"; then
            echo -e "    $WARN: Driver install requires signed modules or SB disable"
        fi
    fi
}

# ─── Result ───
print_summary() {
    local results=("$@")
    local total=${#results[@]}
    local passed=0
    
    for r in "${results[@]}"; do
        [ "$r" = "pass" ] && ((passed++))
    done
    
    echo ""
    echo "========================"
    echo " TAO GPU Host Setup Check"
    echo "========================"
    echo "Passed: $passed/$total"
    
    if [ "$passed" -eq "$total" ]; then
        echo -e "${GREEN}All checks passed. Ready for TAO.${NC}"
    else
        echo -e "${YELLOW}Run with --install to resolve failures.${NC}"
        return 1
    fi
}

# ─── Install Functions ───
install_driver() {
    echo ""
    echo "=== Installing NVIDIA Driver $DRIVER_BRANCH ==="
    
    # Detect OS
    case "$OS_ID" in
        ubuntu|debian)
            # Add NVIDIA repository
            add-apt-repository -y ppa:graphics-drivers/ppa
            apt-get update
            apt-get install -y "nvidia-driver-$DRIVER_BRANCH"
            ;;
        rhel|centos|rocky|almalinux)
            dnf config-manager --add-repo https://developer.download.nvidia.com/compute/cuda/repos/rhel9/x86_64/cuda-rhel9.repo
            dnf install -y "nvidia-driver-$DRIVER_BRANCH"
            ;;
        suse|sles)
            zypper addrepo https://developer.download.nvidia.com/compute/cuda/repos/sles15/x86_64/cuda-sles15.repo
            zypper install -y "nvidia-driver-$DRIVER_BRANCH"
            ;;
        *)
            echo "Unsupported OS: $OS_ID"
            echo "Install NVIDIA driver $DRIVER_BRANCH manually:"
            echo "  https://www.nvidia.com/download.aspx"
            return 1
            ;;
    esac
    
    # Blacklist nouveau
    cat > /etc/modprobe.d/blacklist-nvidia-nouveau.conf << 'EOF'
blacklist nouveau
options nouveau modeset=0
EOF
    update-initramfs -u
    
    echo ""
    echo "Driver installed. Reboot required: sudo reboot"
}

install_cuda() {
    echo ""
    echo "=== Installing CUDA Toolkit $CUDA_VERSION ==="
    
    case "$OS_ID" in
        ubuntu|debian)
            wget -q "https://developer.download.nvidia.com/compute/cuda/repos/${OS_ID}${OS_VERSION}/x86_64/cuda-keyring_1.1-1_all.deb"
            dpkg -i cuda-keyring_1.1-1_all.deb
            apt-get update
            apt-get install -y "cuda-toolkit-$(echo $CUDA_VERSION | tr . -)"
            ;;
        rhel|centos|rocky|almalinux)
            dnf config-manager --add-repo https://developer.download.nvidia.com/compute/cuda/repos/rhel9/x86_64/cuda-rhel9.repo
            dnf install -y "cuda-toolkit-$(echo $CUDA_VERSION | tr . -)"
            ;;
        *)
            echo "Unsupported OS, install CUDA $CUDA_VERSION manually:"
            echo "  https://developer.nvidia.com/cuda-downloads"
            return 1
            ;;
    esac
    
    # Add to PATH
    cat > /etc/profile.d/cuda.sh << 'EOF'
export PATH=/usr/local/cuda/bin:$PATH
export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH
EOF
    chmod +x /etc/profile.d/cuda.sh
    
    echo "CUDA installed. Logout/login or source /etc/profile.d/cuda.sh"
}

install_container_toolkit() {
    echo ""
    echo "=== Installing NVIDIA Container Toolkit $CONTAINER_TOOLKIT_VERSION ==="
    
    case "$OS_ID" in
        ubuntu|debian)
            curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | \
                gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
            curl -sL "https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list" | \
                sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
                tee /etc/apt/sources.list.d/nvidia-container-toolkit.list
            apt-get update
            apt-get install -y "nvidia-container-toolkit=${CONTAINER_TOOLKIT_VERSION}-1"
            ;;
        rhel|centos|rocky|almalinux)
            curl -sL https://nvidia.github.io/libnvidia-container/stable/rpm/nvidia-container-toolkit.repo | \
                tee /etc/yum.repos.d/nvidia-container-toolkit.repo
            dnf install -y "nvidia-container-toolkit-${CONTAINER_TOOLKIT_VERSION}"
            ;;
        *)
            echo "Unsupported OS, install manually:"
            echo "  https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/install-guide.html"
            return 1
            ;;
    esac
    
    # Configure Docker
    nvidia-ctk runtime configure --runtime=docker
    systemctl restart docker
    
    # Configure containerd (for K8s)
    if command -v containerd &>/dev/null; then
        nvidia-ctk runtime configure --runtime=containerd
        systemctl restart containerd
    fi
    
    echo "Container Toolkit installed and configured."
}

install_all() {
    echo ""
    echo "========================================"
    echo " TAO GPU Host Setup — Full Install"
    echo "========================================"
    echo "This will install:"
    echo "  - NVIDIA Driver branch $DRIVER_BRANCH"
    echo "  - CUDA Toolkit $CUDA_VERSION"
    echo "  - NVIDIA Container Toolkit $CONTAINER_TOOLKIT_VERSION"
    echo ""
    echo -e "${RED}WARNING: Driver install may disrupt running GPU workloads.${NC}"
    echo ""
    read -rp "Continue? [y/N]: " confirm
    [ "$confirm" != "y" ] && [ "$confirm" != "Y" ] && { echo "Aborted."; exit 0; }
    
    install_driver
    install_cuda
    install_container_toolkit
    
    echo ""
    echo "========================================"
    echo " Install complete!"
    echo " 1. Reboot for driver to take effect"
    echo " 2. Verify: nvidia-smi"
    echo " 3. Verify: nvcc --version"
    echo " 4. Verify: docker run --rm --gpus all nvidia/cuda:12.0-base nvidia-smi"
    echo "========================================"
}

# ─── Main ───
main() {
    local mode="${1:-check}"
    
    echo "========================================"
    echo " TAO GPU Host Setup"
    echo " Driver: $DRIVER_BRANCH | CUDA: $CUDA_VERSION | CTK: $CONTAINER_TOOLKIT_VERSION"  
    echo "========================================"
    echo "Host: $(hostname) | OS: $OS_ID $OS_VERSION | Kernel: $(uname -r)"
    
    local results=()
    
    # Check (runs on any Linux)
    check_system
    check_gpu && results+=("pass") || results+=("fail")
    check_driver && results+=("pass") || results+=("fail")
    check_cuda && results+=("pass") || results+=("fail")
    check_container_toolkit && results+=("pass") || results+=("fail")
    check_docker && results+=("pass") || results+=("fail")
    check_kubernetes
    
    print_summary "${results[@]}"
    
    # Install mode (requires confirmation)
    if [ "$mode" = "--install" ]; then
        install_all
    fi
}

main "$@"
```

## Uso

```bash
# Apenas checar (funciona em qualquer Linux)
sudo ./tao-gpu-host-setup.sh --check-only

# Instalar (requer confirmação)
sudo ./tao-gpu-host-setup.sh --install

# Ajuda
./tao-gpu-host-setup.sh --help
```

## Verificações Individuais

```bash
# GPU
lspci -d 10de: | grep "3D controller\|VGA"
nvidia-smi --query-gpu=driver_version,persistence_mode --format=csv

# Driver
modinfo nvidia | grep "^version:"
lsmod | grep nvidia

# CUDA
nvcc --version
ldconfig -p | grep libcudart

# Container Toolkit
nvidia-ctk --version
nvidia-ctk runtime configure --help

# Docker
docker info | grep nvidia
docker run --rm --gpus all nvidia/cuda:12.0-base nvidia-smi

# Kubernetes (se aplicável)
kubectl get nodes -o json | jq '.items[].status.capacity'
kubectl describe node | grep nvidia.com/gpu
```

## Tabela de Dependências

| Componente | Versão | Check | Install |
|-----------|--------|-------|---------|
| NVIDIA Driver | Branch 580 | `nvidia-smi` | PPA / repo / runfile |
| CUDA Toolkit | 13.0 | `nvcc --version` | repo / runfile |
| Container Toolkit | 1.19.0 | `nvidia-ctk --version` | NVIDIA repo |
| Docker | CE 24+ | `docker --version` | docker.io repo |
| containerd | 1.7+ | `ctr --version` | Container Toolkit |
| K8s Device Plugin | v0.16+ | `kubectl describe node` | Helm / YAML |

## Tarefas principais

- **Check-only**: GPU, driver, CUDA, container toolkit, Docker, K8s (funciona em qualquer Linux)
- **Install**: driver branch 580, CUDA 13.0, container toolkit 1.19.0 (requer confirmação)
- Validar: nouveau blacklisted, Secure Boot, persistence mode
- Configurar Docker runtime e containerd para GPU
- Verificar GPU passthrough em container
- Verificar GPU capacity no Kubernetes
- **Requires sudo**; driver install requer reboot
