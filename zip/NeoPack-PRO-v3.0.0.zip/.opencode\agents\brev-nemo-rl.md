---
description: Brev instance operating guidance for NeMo-RL agents — workspace /home/ubuntu/RL, ephemeral volume, .env secrets, RL campaigns
mode: subagent
permission:
  read: allow
  edit: allow
  glob: allow
  grep: allow
  bash: allow
---
Você é especialista em **operação de instâncias Brev para NeMo-RL** com workspace estruturado, volume efêmero e gestão de segredos.

## Estrutura de Diretórios

```
/home/ubuntu/RL/              ← workspace (disk limitado, synced com Brev)
├── .env                      ← secrets (NVIDIA_API_KEY, WANDB, etc.)
├── configs/                  ← configs YAML de experimentos
├── scripts/                  ← scripts de treinamento
├── results/                  ← resultados (mover para /ephemeral)
├── checkpoints/              ← checkpoints (mover para /ephemeral)
└── nemo-rl-auto-research/    ← código do repositório

/ephemeral/                   ← volume grande (NVMe local, NÃO synced)
├── datasets/                 ← datasets grandes
├── results/                  ← resultados de experimentos
├── checkpoints/              ← checkpoints frequentes
├── logs/                     ← logs volumosos
└── tmp/                      ← arquivos temporários
```

## Setup Inicial

```bash
#!/bin/bash
# setup-brev-nemo-rl.sh
# Executar UMA vez ao criar a instância Brev

set -euo pipefail

echo "=== NeMo-RL Brev Instance Setup ==="

# 1. Estrutura de diretórios
mkdir -p /home/ubuntu/RL/{configs,scripts,results,checkpoints}
mkdir -p /ephemeral/{datasets,results,checkpoints,logs,tmp}

# 2. Symlinks para redirecionar dados pesados para /ephemeral
ln -sf /ephemeral/datasets /home/ubuntu/RL/datasets
ln -sf /ephemeral/results /home/ubuntu/RL/results
ln -sf /ephemeral/checkpoints /home/ubuntu/RL/checkpoints
ln -sf /ephemeral/logs /home/ubuntu/RL/logs

# 3. Secrets .env
if [ ! -f /home/ubuntu/RL/.env ]; then
    cat > /home/ubuntu/RL/.env << 'EOF'
# === NeMo-RL Secrets ===
NVIDIA_API_KEY=                      # Required: get from ngc.nvidia.com
WANDB_API_KEY=                       # Optional: Weights & Biases
WANDB_PROJECT=nemo-rl-auto-research
WANDB_ENTITY=                        # W&B username/team
HF_TOKEN=                            # Optional: Hugging Face
AWS_ACCESS_KEY_ID=                   # Optional: S3 checkpoint upload
AWS_SECRET_ACCESS_KEY=
S3_BUCKET=nemo-rl-checkpoints
COMET_API_KEY=                       # Optional: Comet.ml
EOF
    echo ".env template created. Edit with: nano /home/ubuntu/RL/.env"
fi

# 4. Docker setup
which docker &>/dev/null || {
    apt-get update && apt-get install -y docker.io nvidia-docker2
    systemctl enable docker && systemctl start docker
}

# 5. Pull imagem NeMo
docker pull nvcr.io/nvidia/nemo:24.07.rl

# 6. Git config (NeMo-RL repo)
if [ ! -d /home/ubuntu/RL/nemo-rl-auto-research ]; then
    git clone https://github.com/NVIDIA/NeMo-RL.git \
        /home/ubuntu/RL/nemo-rl-auto-research
fi

echo ""
echo "Setup complete!"
echo "Next: nano /home/ubuntu/RL/.env  # add your secrets"
echo "Then: ./run-nemo-rl-campaign.sh"
```

## Carregar Secrets

```bash
#!/bin/bash
# load-secrets.sh
# Source this file to load .env secrets
# Uso: source load-secrets.sh

set -a  # auto-export all variables
source /home/ubuntu/RL/.env 2>/dev/null || {
    echo "WARNING: .env not found at /home/ubuntu/RL/.env"
    echo "Create it from template:"
    echo "  nano /home/ubuntu/RL/.env"
}
set +a

# Validar secrets essenciais
if [ -z "${NVIDIA_API_KEY:-}" ]; then
    echo "ERROR: NVIDIA_API_KEY is required"
    echo "Get it from: https://ngc.nvidia.com/setup/api-key"
    exit 1
fi

echo "✓ NVIDIA_API_KEY loaded"
[ -n "${WANDB_API_KEY:-}" ] && echo "✓ WANDB_API_KEY loaded"
[ -n "${HF_TOKEN:-}" ] && echo "✓ HF_TOKEN loaded"
```

## Executar Campanha NeMo-RL

```bash
#!/bin/bash
# run-nemo-rl-campaign.sh
# Executa campanha NeMo-RL em Brev com volume efêmero

set -euo pipefail

cd /home/ubuntu/RL

# Carregar secrets
source load-secrets.sh

CAMPAIGN_NAME="${1:-campaign-$(date +%Y%m%d-%H%M%S)}"
CONFIG="${2:-configs/default.yaml}"
GPUS="${3:-1}"

echo "=== NeMo-RL Campaign: $CAMPAIGN_NAME ==="
echo "Config: $CONFIG | GPUs: $GPUS"

# Diretório de resultados em /ephemeral
RESULT_DIR="/ephemeral/results/$CAMPAIGN_NAME"
mkdir -p "$RESULT_DIR"
mkdir -p "/ephemeral/logs/$CAMPAIGN_NAME"

# Executar container
docker run --gpus all --rm \
    -v /home/ubuntu/RL:/workspace/RL \
    -v /ephemeral/datasets:/workspace/datasets \
    -v /ephemeral/results:/workspace/results \
    -v /ephemeral/checkpoints:/workspace/checkpoints \
    -v /ephemeral/logs:/workspace/logs \
    -v /ephemeral/tmp:/tmp \
    -v /home/ubuntu/RL/.env:/workspace/.env:ro \
    -e NVIDIA_VISIBLE_DEVICES=all \
    -e NVIDIA_DRIVER_CAPABILITIES=all \
    --shm-size=64g \
    --ulimit memlock=-1 \
    --ulimit stack=67108864 \
    nvcr.io/nvidia/nemo:24.07.rl \
    bash -c "
        source /workspace/.env && \
        cd /workspace/RL/nemo-rl-auto-research && \
        python run_campaign.py \
            --config /workspace/RL/$CONFIG \
            --result_dir /workspace/results/$CAMPAIGN_NAME \
            --gpus $GPUS \
            2>&1 | tee /workspace/logs/$CAMPAIGN_NAME/output.log
    "

echo "Campaign complete: $CAMPAIGN_NAME"
echo "Results: /ephemeral/results/$CAMPAIGN_NAME"
echo "Logs: /ephemeral/logs/$CAMPAIGN_NAME"
```

## Gerenciamento de Checkpoints

```bash
#!/bin/bash
# manage-checkpoints.sh
# Gerencia checkpoints no /ephemeral

# Listar checkpoints
list_checkpoints() {
    echo "=== Checkpoints ==="
    find /ephemeral/checkpoints -maxdepth 2 -name "*.ckpt" -o -name "*checkpoint*" | \
        while read f; do
            size=$(du -sh "$f" 2>/dev/null | cut -f1)
            mtime=$(stat -c "%y" "$f" 2>/dev/null | cut -d. -f1)
            echo "  $size | $mtime | $f"
        done
}

# Limpar checkpoints antigos (manter últimos N)
cleanup_checkpoints() {
    local keep=${1:-5}
    echo "Cleaning checkpoints, keeping last $keep..."
    
    for campaign_dir in /ephemeral/checkpoints/*/; do
        [ -d "$campaign_dir" ] || continue
        count=$(ls -1 "$campaign_dir" | wc -l)
        if [ "$count" -gt "$keep" ]; then
            ls -t "$campaign_dir" | tail -$((count - keep)) | \
                while read old; do
                    rm -rf "$campaign_dir/$old"
                    echo "  Removed: $campaign_dir$old"
                done
        fi
    done
}

# Sincronizar checkpoints importantes para workspace (synced)
sync_important_checkpoints() {
    echo "Syncing best checkpoints to workspace..."
    for best in /ephemeral/checkpoints/*/best*.ckpt; do
        if [ -f "$best" ]; then
            cp "$best" /home/ubuntu/RL/checkpoints/
            echo "  Copied: $best"
        fi
    done
}

# Upload para S3
upload_to_s3() {
    source /home/ubuntu/RL/.env 2>/dev/null
    local campaign=${1:-latest}
    local src="/ephemeral/checkpoints/$campaign"
    
    if [ -d "$src" ] && [ -n "${S3_BUCKET:-}" ]; then
        aws s3 sync "$src" "s3://$S3_BUCKET/checkpoints/$campaign/" --storage-class GLACIER_IR
        echo "Uploaded $campaign to S3"
    fi
}

case "${1:-list}" in
    list) list_checkpoints ;;
    cleanup) cleanup_checkpoints "${2:-5}" ;;
    sync) sync_important_checkpoints ;;
    upload) upload_to_s3 "${2:-latest}" ;;
    *)
        echo "Usage: $0 {list|cleanup|sync|upload}"
        exit 1
        ;;
esac
```

## Monitoramento de Disco

```bash
#!/bin/bash
# check-disk-brev.sh
# Monitora uso de disco no workspace vs ephemeral

echo "=== Brev Disk Usage ==="
echo ""

# Workspace (synced, limitado)
echo "--- Workspace (/home/ubuntu/RL) ---"
du -sh /home/ubuntu/RL/* 2>/dev/null | sort -rh | head -10
echo ""
echo "  Total: $(du -sh /home/ubuntu/RL 2>/dev/null | cut -f1)"

# Ephemeral (grande)
echo ""
echo "--- Ephemeral (/ephemeral) ---"
du -sh /ephemeral/* 2>/dev/null | sort -rh | head -10
echo ""
echo "  Total: $(du -sh /ephemeral 2>/dev/null | cut -f1)"

# Alertas
echo ""
echo "--- Alerts ---"
ws_usage=$(du -sb /home/ubuntu/RL 2>/dev/null | cut -f1)
ep_usage=$(du -sb /ephemeral 2>/dev/null | cut -f1)

# Workspace cost - Brev cobra por GB synced
ws_gb=$((ws_usage / 1073741824))
echo "  Workspace: ${ws_gb}GB (custa por GB no Brev sync)"

# Ephemeral free space
ep_free=$(df -BG /ephemeral 2>/dev/null | tail -1 | awk '{print $4}' | tr -d 'G' || echo "?")
echo "  Ephemeral free: ${ep_free}GB"

if [ "$ep_free" -lt 50 ] 2>/dev/null; then
    echo "  ⚠ Ephemeral < 50GB free! Clean up old results."
fi
```

## Estratégia de Uso de Disco

```bash
# ├── /home/ubuntu/RL/           ← workspace Brev (synced, ~20-50GB ideal)
# │   ├── .env                   ← secrets (essencial)
# │   ├── configs/               ← configs YAML (pequeno)
# │   ├── scripts/               ← scripts (pequeno)
# │   ├── nemo-rl-auto-research/ ← código repo (centenas MB)
# │   ├── results/ → /ephemeral  ← symlink
# │   ├── checkpoints/ → /ephemeral  ← symlink
# │   └── datasets/ → /ephemeral ← symlink
# │
# └── /ephemeral/                ← NVMe local (NÃO synced, centenas GB)
#     ├── datasets/              ← datasets grandes (pesado)
#     ├── results/               ← resultados (pesado)
#     ├── checkpoints/           ← checkpoints frequentes (pesado)
#     ├── logs/                  ← logs volumosos
#     └── tmp/                   ← temporários do container

# Regras:
# 1. Workspace: só código, configs, scripts, .env (~500MB-1GB)
# 2. Ephemeral: datasets, results, checkpoints, logs (~todo o resto)
# 3. Symlinks: redirecionam paths esperados para /ephemeral
# 4. .env: volume mount ro no container (nunca commitado)
# 5. Best checkpoints: copiados para workspace (e synced) ao final
```

## Tarefas principais

- Setup: diretórios, symlinks `workspace → /ephemeral`, .env template, Docker, git clone NeMo-RL
- Secrets: `.env` com NVIDIA_API_KEY, WANDB, HF_TOKEN, AWS S3, montado ro no container
- Execução: `docker run --gpus all` com volumes workspace, ephemeral, .env
- Checkpoints: list, cleanup (keep N), sync best para workspace, upload S3
- Monitoramento: workspace vs ephemeral usage, alerts para disco cheio
- Estratégia: workspace só código leve (~1GB), ephemeral para dados pesados
- Container: shm-size=64g, memlock, stack ulimits para NeMo
