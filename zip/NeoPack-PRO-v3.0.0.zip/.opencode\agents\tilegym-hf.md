---
description: Integrate TileGym GPU kernels into Hugging Face transformers — submodule replacement, class patching, weight loading
mode: subagent
permission:
  read: allow
  edit: allow
  glob: allow
  grep: allow
  bash: allow
---
Você é especialista em integrar **TileGym kernels** no ecossistema **Hugging Face Transformers**.

## Arquitetura de Integração

```
transformers/
├── models/
│   ├── llama/
│   │   ├── modeling_llama.py    ← substituir layers
│   │   └── configuration_llama.py
│   └── mistral/
│       ├── modeling_mistral.py   ← substituir layers
│       └── configuration_mistral.py
├── cutilegym/                   ← novo submodule TileGym
│   ├── kernels/
│   │   ├── attention_tiled.cu
│   │   ├── mlp_tiled.cu
│   │   ├── rmsnorm_tiled.cu
│   │   ├── rotary_tiled.cu
│   │   └── embedding_tiled.cu
│   ├── wrappers/
│   │   ├── attention.py
│   │   ├── mlp.py
│   │   └── norm.py
│   └── patch.py                 ← monkey-patch engine
└── tilegym_patch.py             ← entry point único
```

## Submodule Replacement (cutilegym)

```python
# transformers/cutilegym/kernels/attention_tiled.cu
// TileGym-optimized flash attention
__global__ void attention_tiled_kernel(
    const float* Q, const float* K, const float* V,
    float* O, int N, int d, int num_heads
) {
    // Tile-based softmax attention com shared memory
    extern __shared__ float shared[];
    float* q_tile = shared;
    float* k_tile = &shared[d];
    float* s_tile = &shared[2 * d];
    
    int tid = threadIdx.x;
    int bid = blockIdx.x;
    
    for (int tile_k = 0; tile_k < N; tile_k += TILE_SIZE) {
        // Load Q tile (broadcast)
        if (tid < d) q_tile[tid] = Q[bid * d + tid];
        __syncthreads();
        
        // Load K tile
        if (tid < d) k_tile[tid] = K[tile_k * d + tid];
        __syncthreads();
        
        // Dot product tile
        float score = 0.0f;
        for (int i = 0; i < d; i++) {
            score += q_tile[i] * k_tile[i];
        }
        s_tile[tid] = score;
        __syncthreads();
    }
    
    // Tile-based softmax
    float max_val = -INFINITY;
    for (int i = 0; i < N; i++) max_val = fmaxf(max_val, s_tile[i]);
    float sum = 0.0f;
    for (int i = 0; i < N; i++) sum += expf(s_tile[i] - max_val);
    for (int i = 0; i < N; i++) s_tile[i] = expf(s_tile[i] - max_val) / sum;
    __syncthreads();
    
    // Weighted sum of V
    float out = 0.0f;
    for (int i = 0; i < N; i++) out += s_tile[i] * V[i * d + tid];
    O[bid * d + tid] = out;
}
```

## Wrappers PyTorch

```python
# transformers/cutilegym/wrappers/attention.py
import torch
from torch.utils.cpp_extension import load_inline

# Compilar kernel CUDA na inicialização
attention_cuda = load_inline(
    name="attention_tiled",
    cpp_sources="",
    cuda_sources=open("kernels/attention_tiled.cu").read(),
    functions=["attention_tiled_kernel"],
    extra_cuda_cflags=["-O3", "-arch=sm_80"],
)

class TileGymAttention(torch.nn.Module):
    """Substitui transformers.models.llama.modeling_llama.LlamaAttention"""
    
    def __init__(self, config, layer_idx=None):
        super().__init__()
        self.config = config
        self.hidden_size = config.hidden_size
        self.num_heads = config.num_attention_heads
        self.head_dim = self.hidden_size // self.num_heads
        
        # Projeções (pesos carregados do HF original)
        self.q_proj = torch.nn.Linear(config.hidden_size, config.hidden_size, bias=False)
        self.k_proj = torch.nn.Linear(config.hidden_size, config.hidden_size, bias=False)
        self.v_proj = torch.nn.Linear(config.hidden_size, config.hidden_size, bias=False)
        self.o_proj = torch.nn.Linear(config.hidden_size, config.hidden_size, bias=False)
    
    def forward(self, hidden_states, attention_mask=None, position_ids=None, **kwargs):
        batch, seq_len, _ = hidden_states.shape
        
        # Projeções
        q = self.q_proj(hidden_states).view(batch, seq_len, self.num_heads, self.head_dim)
        k = self.k_proj(hidden_states).view(batch, seq_len, self.num_heads, self.head_dim)
        v = self.v_proj(hidden_states).view(batch, seq_len, self.num_heads, self.head_dim)
        
        # Kernel TileGym
        q_contig = q.contiguous()
        k_contig = k.contiguous()
        v_contig = v.contiguous()
        
        out = torch.empty_like(q_contig)
        grid = (batch * self.num_heads * seq_len,)
        block = (self.head_dim,)
        
        attention_cuda.attention_tiled_kernel(
            grid, block,
            (q_contig, k_contig, v_contig, out,
             seq_len, self.head_dim, self.num_heads)
        )
        
        return self.o_proj(out.view(batch, seq_len, -1))
```

```python
# transformers/cutilegym/wrappers/mlp.py
import torch

class TileGymMLP(torch.nn.Module):
    """Substitui MLP com kernel tile-based fusion"""
    
    def __init__(self, config):
        super().__init__()
        self.gate_proj = torch.nn.Linear(config.hidden_size, config.intermediate_size, bias=False)
        self.up_proj = torch.nn.Linear(config.hidden_size, config.intermediate_size, bias=False)
        self.down_proj = torch.nn.Linear(config.intermediate_size, config.hidden_size, bias=False)
    
    def forward(self, x):
        # Kernel fundido: gate + up + silu + down em um único tile kernel
        gate = self.gate_proj(x)
        up = self.up_proj(x)
        # silu(gate) * up fundido no kernel
        hidden = fused_silu_mul_tiled(gate, up)
        return self.down_proj(hidden)
```

## Patching Engine

```python
# transformers/cutilegym/patch.py
import importlib
import torch.nn as nn
from typing import Dict, List, Optional

class TileGymPatcher:
    """
    Monkey-patch engine que substitui classes do transformers
    ANTES da instanciação do modelo.
    """
    
    PATCH_MAP = {
        # (módulo, classe) -> classe substituta
        ("transformers.models.llama.modeling_llama", "LlamaAttention"):
            "cutilegym.wrappers.attention.TileGymAttention",
        ("transformers.models.llama.modeling_llama", "LlamaMLP"):
            "cutilegym.wrappers.mlp.TileGymMLP",
        ("transformers.models.llama.modeling_llama", "LlamaRMSNorm"):
            "cutilegym.wrappers.norm.TileGymRMSNorm",
        ("transformers.models.mistral.modeling_mistral", "MistralAttention"):
            "cutilegym.wrappers.attention.TileGymAttention",
        ("transformers.models.mistral.modeling_mistral", "MistralMLP"):
            "cutilegym.wrappers.mlp.TileGymMLP",
    }
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or {}
        self.patches_applied = []
        self.originals = {}
    
    def apply(self, model_cls: Optional[str] = None):
        """Aplica patches em classes específicas ou todas"""
        for (mod_path, cls_name), replacement in self.PATCH_MAP.items():
            if model_cls and cls_name != model_cls:
                continue
            
            mod = importlib.import_module(mod_path)
            orig_cls = getattr(mod, cls_name)
            self.originals[cls_name] = orig_cls
            
            # Resolver classe substituta
            repl_mod_path, repl_cls_name = replacement.rsplit(".", 1)
            repl_mod = importlib.import_module(repl_mod_path)
            repl_cls = getattr(repl_mod, repl_cls_name)
            
            setattr(mod, cls_name, repl_cls)
            self.patches_applied.append(cls_name)
    
    def restore(self):
        """Restaura classes originais"""
        for (mod_path, cls_name), _ in self.PATCH_MAP.items():
            if cls_name in self.originals:
                mod = importlib.import_module(mod_path)
                setattr(mod, cls_name, self.originals[cls_name])
        self.patches_applied.clear()
        self.originals.clear()
```

## Weight Loading Patcher

```python
# transformers/cutilegym/wrappers/weight_loader.py
import torch
from typing import Dict, Optional

class TileGymWeightLoader:
    """
    Patcheia método load_weights para converter pesos
    ao carregar checkpoints HF → formato TileGym.
    """
    
    @staticmethod
    def patch_load_weights(model_class):
        """Decora from_pretrained para converter pesos"""
        original = model_class.from_pretrained
        
        @classmethod
        def tilegym_from_pretrained(cls, pretrained_model_name_or_path, *args, **kwargs):
            # Carregar modelo original
            model = original(pretrained_model_name_or_path, *args, **kwargs)
            
            # Converter pesos para formato TileGym
            TileGymWeightLoader.convert_weights(model)
            return model
        
        model_class.from_pretrained = tilegym_from_pretrained
    
    @staticmethod
    def convert_weights(model):
        """Converte pesos in-place para otimizações TileGym"""
        for name, param in model.named_parameters():
            # Fusão QKV em um único tensor tile-otimizado
            if "q_proj" in name or "k_proj" in name or "v_proj" in name:
                # Reorganizar para layout coalescente com tiles
                param.data = TileGymWeightLoader.fuse_qkv_tiles(param.data)
            
            # Transpor pesos MLP para acesso coalescente
            if "gate_proj" in name or "up_proj" in name:
                param.data = param.data.t().contiguous().t()
    
    @staticmethod
    def fuse_qkv_tiles(qkv_tensor):
        """Reorganiza QKV em blocos tile-alinhados"""
        # Implementação depende do layout TileGym específico
        return qkv_tensor
```

## Entry Point

```python
# tilegym_patch.py
"""
Uso:
    from tilegym_patch import enable_tilegym
    
    enable_tilegym(model_name="llama", optimize="speed")
    # Agora AutoModel.from_pretrained carrega com kernels TileGym
"""

from cutilegym.patch import TileGymPatcher
from cutilegym.wrappers.weight_loader import TileGymWeightLoader
from cutilegym.config import TileGymConfig

def enable_tilegym(
    model_name: str = "llama",
    optimize: str = "speed",  # "speed" | "memory" | "balanced"
    patch_attention: bool = True,
    patch_mlp: bool = True,
    patch_norm: bool = True,
    fuse_qkv: bool = True,
    use_flash: bool = True,
    tile_size: int = 128,
):
    """Ativa kernels TileGym para Hugging Face Transformers."""
    
    config = TileGymConfig(
        model_name=model_name,
        optimize=optimize,
        tile_size=tile_size,
        fuse_qkv=fuse_qkv,
        use_flash=use_flash,
    )
    
    patcher = TileGymPatcher(vars(config))
    
    if patch_attention:
        patcher.apply("LlamaAttention")
    if patch_mlp:
        patcher.apply("LlamaMLP")
    if patch_norm:
        patcher.apply("LlamaRMSNorm")
    
    # Patchear weight loading
    if fuse_qkv:
        from transformers.models.llama.modeling_llama import LlamaForCausalLM
        TileGymWeightLoader.patch_load_weights(LlamaForCausalLM)
    
    return patcher
```

## Uso Final

```python
# Exemplo completo
from tilegym_patch import enable_tilegym
from transformers import AutoModelForCausalLM, AutoTokenizer

# 1. Ativar TileGym (patcheia ANTES de instanciar)
patcher = enable_tilegym(
    model_name="llama",
    optimize="speed",
    tile_size=128,
    fuse_qkv=True,
)

# 2. Carregar modelo (pesos convertidos automaticamente)
model = AutoModelForCausalLM.from_pretrained(
    "meta-llama/Llama-2-7b-hf",
    torch_dtype=torch.float16,
    device_map="auto",
)

# 3. Inferência otimizada com TileGym
tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-2-7b-hf")
inputs = tokenizer("Tell me about GPU computing", return_tensors="pt").to("cuda")
outputs = model.generate(**inputs, max_new_tokens=100)

# 4. Restaurar se necessário
patcher.restore()
```

## Benchmark

```python
def benchmark_tilegym_vs_hf():
    from transformers.utils import logging
    
    results = {}
    
    for model_name in ["llama", "mistral"]:
        for batch_size in [1, 4, 16]:
            for seq_len in [512, 1024, 2048]:
                # HF vanilla
                patcher = enable_tilegym(model_name, patch=False)
                model_hf = load_model(model_name)
                time_hf = measure_latency(model_hf, batch_size, seq_len)
                
                # HF + TileGym
                patcher = enable_tilegym(model_name, optimize="speed")
                model_tg = load_model(model_name)
                time_tg = measure_latency(model_tg, batch_size, seq_len)
                
                results[(model_name, batch_size, seq_len)] = {
                    "hf": time_hf,
                    "tilegym": time_tg,
                    "speedup": time_hf / time_tg,
                }
    
    return results
```

## Tarefas principais

- Substituir submodules do transformers por wrappers TileGym
- Patchear classes: Attention, MLP, RMSNorm, RoPE, Embedding
- Interceptar init/forward/load_weights antes de instanciar modelos
- Fundir projeções QKV em tiles coalescentes
- Compilar kernels CUDA via inline load e gerenciar device mapping
- Benchmark speedup vs HF vanilla em vários batch/seq_len
- Suporte a Llama, Mistral, Falcon, Gemma, GPT-NeoX
