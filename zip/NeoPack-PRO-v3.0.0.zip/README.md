# NeoPack PRO v3.0.0

**Licença PRO** — 1 desenvolvedor · 3 máquinas · 3 meses de atualizações

## Conteúdo

### 🤖 48 Agentes (12 categorias)
- Core, Web, Dados, GPU/CUDA, cuTile, ML/DL, Jetson/BSP, TAO/NVIDIA
- Rust, Mobile, Docker/K8s, Infra, Banco, Testes, Docs, Segurança, MLOps, Redes, Game Dev, Web3, DevOps

### 🔌 12 MCP Servers
Puppeteer, Playwright, GitHub, Brave Search, Sequential Thinking, SQLite, Memory, Filesystem, PostgreSQL, Redis, Figma, Notion

### 🎯 7 LSPs + 3 Formatters
Go, TypeScript, HTML, CSS, JSON, Python, Markdown · Prettier, Ruff, Gofmt

### 🖥️ 7 Plataformas
Windows, Ubuntu/Debian, RHEL/Fedora, macOS, Docker, Dev Container, GitHub Codespaces

## Instalação

**Windows (como Administrador):**
```powershell
.\scripts\setup.ps1
```

**Linux/macOS:**
```bash
chmod +x scripts/setup.sh && ./scripts/setup.sh
```

## Suporte
- E-mail: neopack@email.com
- Prazo: 7 dias após ativação
- Resposta em até 24h úteis

© 2026 NeoPack. Todos os direitos reservados.
