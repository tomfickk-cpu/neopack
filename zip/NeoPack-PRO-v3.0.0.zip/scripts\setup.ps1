<#
.SYNOPSIS
    NeoPack PRO v3.0.0 — 1-click PRO setup for Windows
.DESCRIPTION
    Installs OpenCode + all configs, LSPs, MCPs, formatters, and 48 AI agents
.LICENSE
    PRO License — 1 developer, 3 machines, 3 months updates
#>

$ErrorActionPreference = "Stop"
$NeoPackRoot = Split-Path -Parent $PSScriptRoot

Write-Host "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║        NeoPack PRO v3.0.0 Setup        ║" -ForegroundColor Cyan
Write-Host "║    48 Agents · 12 MCPs · 7 LSPs        ║" -ForegroundColor Cyan
Write-Host "║    Licença PRO · Suporte 7 dias         ║" -ForegroundColor Cyan
Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Cyan

# License validation
$LicenseFile = "$NeoPackRoot\LICENSE.txt"
if (Test-Path $LicenseFile) {
    $LicenseContent = Get-Content $LicenseFile -Raw
    Write-Host "✓ Licença PRO verificada" -ForegroundColor Green
} else {
    Write-Host "⚠ Arquivo de licença não encontrado. Continuando..." -ForegroundColor Yellow
}

# 1. Check Node.js
try {
    $nodeVer = node --version
    Write-Host "✓ Node.js $nodeVer" -ForegroundColor Green
} catch {
    Write-Host "✗ Node.js required. Download from https://nodejs.org" -ForegroundColor Red
    exit 1
}

# 2. Install OpenCode CLI
Write-Host "`nInstalling OpenCode CLI..." -ForegroundColor Yellow
npm install -g @opencode/cli

# 3. Install MCP servers (PRO: all 12)
Write-Host "`nInstalling MCP Servers..." -ForegroundColor Yellow
@(
    "@anthropic/mcp-server-puppeteer",
    "@anthropic/mcp-server-playwright",
    "@anthropic/mcp-server-github",
    "@anthropic/mcp-server-brave-search",
    "@modelcontextprotocol/server-sequential-thinking",
    "@modelcontextprotocol/server-sqlite",
    "@modelcontextprotocol/server-memory",
    "@modelcontextprotocol/server-filesystem",
    "@modelcontextprotocol/server-postgres",
    "@modelcontextprotocol/server-redis",
    "@iflow-mcp/figma-mcp",
    "@notionhq/notion-mcp-server"
) | ForEach-Object {
    npm install -g $_
    Write-Host "  ✓ $_" -ForegroundColor Green
}

# 4. Install LSPs
Write-Host "`nInstalling LSPs..." -ForegroundColor Yellow
npm install -g typescript-language-server vscode-langservers-extracted
pip install ruff

# 5. Install formatters
Write-Host "`nInstalling Formatters..." -ForegroundColor Yellow
npm install -g prettier

# 6. Copy configs
Write-Host "`nCopying Configs..." -ForegroundColor Yellow
$ConfigDir = "$env:USERPROFILE\.config\opencode"
New-Item -ItemType Directory -Path $ConfigDir -Force | Out-Null
Copy-Item "$NeoPackRoot\config\opencode.jsonc" "$ConfigDir\opencode.jsonc" -Force

# 7. Init project
Write-Host "`nInitializing NeoPack PRO Project..." -ForegroundColor Yellow
$ProjectDir = "$env:USERPROFILE\NeoPack-PRO"
New-Item -ItemType Directory -Path $ProjectDir -Force | Out-Null
Copy-Item "$NeoPackRoot\.opencode" "$ProjectDir\" -Recurse -Force
Copy-Item "$NeoPackRoot\.opencode\opencode.json" "$ProjectDir\.opencode\opencode.json" -Force

Write-Host "`n╔══════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║  NeoPack PRO v3.0.0 installed!         ║" -ForegroundColor Green
Write-Host "║  48 agents · 12 MCPs · 7 LSPs          ║" -ForegroundColor Green
Write-Host "║  cd ~\NeoPack-PRO                       ║" -ForegroundColor Green
Write-Host "║  opencode                               ║" -ForegroundColor Green
Write-Host "║  Suporte PRO: neopack@email.com         ║" -ForegroundColor Green
Write-Host "╚══════════════════════════════════════════╝" -ForegroundColor Green
