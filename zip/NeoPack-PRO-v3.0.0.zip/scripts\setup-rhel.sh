#!/bin/bash
# NeoPack PRO v3.0.0 — 1-click setup for RHEL/Fedora/CentOS
set -euo pipefail

NEO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "╔══════════════════════════════════════════╗"
echo "║   NeoPack PRO v3.0.0 Setup (RHEL)      ║"
echo "╚══════════════════════════════════════════╝"

# 1. Node.js
if ! command -v node &>/dev/null; then
    curl -fsSL https://rpm.nodesource.com/setup_20.x | bash -
    dnf install -y nodejs
fi

# 2. System deps
dnf install -y git python3 python3-pip golang

# 3. OpenCode
npm install -g @opencode/cli

# 4. MCPs (PRO: all 12)
npm install -g \
    @anthropic/mcp-server-puppeteer \
    @anthropic/mcp-server-playwright \
    @anthropic/mcp-server-github \
    @anthropic/mcp-server-brave-search \
    @modelcontextprotocol/server-sequential-thinking \
    @modelcontextprotocol/server-sqlite \
    @modelcontextprotocol/server-memory \
    @modelcontextprotocol/server-filesystem \
    @modelcontextprotocol/server-postgres \
    @modelcontextprotocol/server-redis \
    @iflow-mcp/figma-mcp \
    @notionhq/notion-mcp-server

# 5. LSPs
npm install -g typescript-language-server vscode-langservers-extracted
pip3 install ruff

# 6. Formatters
npm install -g prettier
go install golang.org/x/tools/gopls@latest

# 7. Configs
CONFIG_DIR="$HOME/.config/opencode"
mkdir -p "$CONFIG_DIR"
cp "$NEO_ROOT/config/opencode.jsonc" "$CONFIG_DIR/opencode.jsonc"

# 8. Project
PROJECT_DIR="$HOME/NeoPack-PRO"
mkdir -p "$PROJECT_DIR/.opencode"
cp -r "$NEO_ROOT/.opencode/agents" "$PROJECT_DIR/.opencode/"
cp "$NEO_ROOT/.opencode/opencode.json" "$PROJECT_DIR/.opencode/opencode.json"

echo "NeoPack PRO v3.0.0 installed! cd ~/NeoPack-PRO && opencode"
