# 📦 NeoPack v3.0.0 — Catálogo Completo

## 🤖 Agentes (48)

| # | Categoria | Agente | Descrição |
|---|-----------|--------|-----------|
| 1 | 🧠 Core | **explore** | Busca rápida em codebase (grep/glob) |
| 2 | 🧠 Core | **build-assistant** | Build, lint, typecheck, documentação |
| 3 | 🧠 Core | **code-review** | Revisão de código (qualidade, segurança, perf) |
| 4 | 🧠 Core | **general** | Propósito geral — pesquisa e multi-step tasks |
| 5 | 🧠 Core | **customize-opencode** | Configuração do OpenCode |
| 6 | 🌐 Web | **web-dev** | HTML/CSS/JS — DOM, Flexbox, Grid, responsivo |
| 7 | 🌐 Web | **seo-qa** | SEO, acessibilidade, performance, testes visuais |
| 8 | 🌐 Web | **content-mapper** | Mapeamento e sincronização de conteúdo |
| 9 | 🌐 Web | **image-processor** | Processamento e validação de imagens |
| 10 | 📊 Dados | **data-pipeline** | Pipeline de dados (CSV, JSON, Excel, SQLite) |
| 11 | 📊 Dados | **db-agent** | SQLite — tabelas, consultas, relatórios |
| 12 | 📊 Dados | **pdf-processor** | Extração e processamento de PDFs |
| 13 | ⚡ GPU/CUDA | **cudf-agent** | GPU DataFrame (cuDF) — pandas em GPU |
| 14 | ⚡ GPU/CUDA | **cuopt-agent** | Otimização com cuOpt (GPU) |
| 15 | ⚡ GPU/CUDA | **cuda-q-agent** | Computação quântica com CUDA-Q |
| 16 | ⚡ GPU/CUDA | **cupynumeric-agent** | NumPy-like em GPU com cuPyNumeric |
| 17 | 🔲 cuTile | **cutile-agent** | GPU kernels tile-based com cuTile |
| 18 | 🔲 cuTile | **tilegym-hf** | TileGym + Hugging Face Transformers |
| 19 | 🔲 cuTile | **cutile-optimizer** | Otimização iterativa de kernels cuTile |
| 20 | 🔲 cuTile | **cutile-autotune** | Autotuning CuTile (exhaustive_search, hints_fn) |
| 21 | 🔲 cuTile | **cutile-to-triton** | Conversor cuTile → Triton |
| 22 | 🔲 cuTile | **cutile-py2jl** | Conversor cuTile Python → Julia |
| 23 | 🔲 cuTile | **cutile-pareto** | Fronteira de Pareto com cuOpt |
| 24 | 🤖 ML/DL | **tilegym-hf** | TileGym + Hugging Face Transformers |
| 25 | 🤖 ML/DL | **portfolio-optimizer** | Mean-CVaR, fronteira eficiente, backtest |
| 26 | 🤖 ML/DL | **optimization-concepts** | Conceitos de otimização (LP, MILP, QUBO) |
| 27 | 📟 Jetson/BSP | **jetson-dram-reclaim** | Reclaim DRAM em Jetson (MB1/MB2/DT/SWIOTLB) |
| 28 | 📟 Jetson/BSP | **jetson-headless-memory** | Reclaim memória GUI/daemons em Jetson |
| 29 | 📟 Jetson/BSP | **jetson-mgbe-qsfp** | MGBE QSFP 25G/10G/1G via DT overlay |
| 30 | 📟 Jetson/BSP | **jetson-clock-lock** | Lock/cap clocks CPU/GPU/EMC via BPMP DTB |
| 31 | 📟 Jetson/BSP | **bsp-promote** | Promover overlays/artefatos para BSP image |
| 32 | 🎯 TAO/NVIDIA | **tao-gpu-host** | Host setup para TAO (driver 580, CUDA 13.0) |
| 33 | 🎯 TAO/NVIDIA | **tao-k8s** | TAO jobs como k8s Jobs com GPU |
| 34 | 🎯 TAO/NVIDIA | **brev-tao** | Brev GPU instances para TAO |
| 35 | 🎯 TAO/NVIDIA | **brev-nemo-rl** | Brev + NeMo-RL com /ephemeral volume |
| 36 | 🔧 DevOps | **go-dev** | Desenvolvimento Go (compilação, testes, LSP) |
| 37 | 🔧 DevOps | **script-automation** | Automação (Python, Batch, PowerShell) |
| 38 | 🦀 Rust | **rust-dev** | Rust — cargo, clippy, rust-analyzer, async |
| 39 | 📱 Mobile | **mobile-dev** | React Native, Expo, Flutter |
| 40 | 🐳 Docker/K8s | **docker-agent** | Dockerfiles, compose, K8s manifests, Helm |
| 41 | 🌍 Infra | **terraform-agent** | Terraform, AWS, GCP, Azure, IaC |
| 42 | 🗄️ Banco | **postgres-agent** | SQL avançado, migrations, performance tuning |
| 43 | 🧪 Testes | **test-automation** | Jest, Pytest, Playwright, Cypress |
| 44 | 📘 Docs | **docs-generator** | JSDoc, TypeDoc, Sphinx, Docusaurus |
| 45 | 🔐 Segurança | **security-audit** | SAST, dependency scan, OWASP, secrets |
| 46 | 📈 MLOps | **mlops-agent** | MLflow, DVC, pipelines, model registry |
| 47 | 📡 Redes | **network-agent** | TCP/IP, DNS, HTTP, tcpdump, proxies |
| 48 | ⛓️ Web3 | **web3-agent** | Solidity, ethers.js, Hardhat, DeFi, NFTs |
| — | 🎮 Game Dev | **game-dev** | Godot 4, Unity C#, Unreal Blueprints |

## 🔌 MCP Servers (12)

| Server | Descrição |
|--------|-----------|
| Puppeteer | Automação de browser headless |
| Playwright | Automação cross-browser |
| GitHub | API do GitHub (PRs, issues, repositórios) |
| Brave Search | Pesquisa web |
| Sequential Thinking | Raciocínio estruturado |
| SQLite | Banco de dados SQLite |
| Memory | Grafo de conhecimento persistente |
| Filesystem | Acesso ao sistema de arquivos |
| PostgreSQL | Query e schema de banco PostgreSQL |
| Redis | Cache, pub/sub, filas |
| Figma | Design tokens e componentes |
| Notion | Páginas e databases do Notion |

## 🎯 LSPs (7)

Go (gopls), TypeScript, HTML, CSS, JSON, Python (ruff), Markdown

## ✨ Formatters (3)

Go (gofmt), Prettier, Python (ruff)

## 🔧 Plugins (2)

@op1/code-graph, @op1/code-intel

## 🖥️ Plataformas (7)

Windows, Ubuntu/Debian, RHEL/Fedora, macOS, Docker, Dev Container, GitHub Codespaces
