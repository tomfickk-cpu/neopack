#!/bin/bash
# NeoPack PRO v3.0.0 — 1-click setup for macOS
set -euo pipefail

NEO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "╔══════════════════════════════════════════╗"
echo "║   NeoPack PRO v3.0.0 Setup (macOS)     ║"
echo "║  48 Agents · 12 MCPs · 7 LSPs          ║"
echo "╚══════════════════════════════════════════╝"

# 1. Homebrew
if ! command -v brew &>/dev/null; then
    echo "Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
fi

# 2. Node.js
if ! command -v node &>/dev/null; then
    brew install node
fi
echo "✓ Node.js $(node --version)"

# 3. System deps
brew install git python go

# 4. OpenCode CLI
npm install -g @opencode/cli

# 5. MCP Servers
MCP_PACKAGES=(
    "@anthropic/mcp-server-puppeteer"
    "@anthropic/mcp-server-playwright"
    "@anthropic/mcp-server-github"
    "@anthropic/mcp-server-brave-search"
    "@modelcontextprotocol/server-sequential-thinking"
    "@modelcontextprotocol/server-sqlite"
    "@modelcontextprotocol/server-memory"
    "@modelcontextprotocol/server-filesystem"
    "@modelcontextprotocol/server-postgres"
    "@modelcontextprotocol/server-redis"
    "@iflow-mcp/figma-mcp"
    "@notionhq/notion-mcp-server"
)
for pkg in "${MCP_PACKAGES[@]}"; do
    npm install -g "$pkg"
    echo "  ✓ $pkg"
done

# 6. LSPs
npm install -g typescript-language-server vscode-langservers-extracted
pip3 install ruff

# 7. Formatters
npm install -g prettier
go install golang.org/x/tools/gopls@latest

# 8. Configs
CONFIG_DIR="$HOME/.config/opencode"
mkdir -p "$CONFIG_DIR"
cp "$NEO_ROOT/config/opencode.jsonc" "$CONFIG_DIR/opencode.jsonc"

# 9. Project
PROJECT_DIR="$HOME/NeoPack-PRO"
mkdir -p "$PROJECT_DIR/.opencode"
cp -r "$NEO_ROOT/.opencode/agents" "$PROJECT_DIR/.opencode/"
cp "$NEO_ROOT/.opencode/opencode.json" "$PROJECT_DIR/.opencode/opencode.json"

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  NeoPack PRO v3.0.0 installed!         ║"
echo "║  cd ~/NeoPack-PRO                       ║"
echo "╚══════════════════════════════════════════╝"
