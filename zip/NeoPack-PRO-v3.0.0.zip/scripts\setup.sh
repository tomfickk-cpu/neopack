#!/bin/bash
# NeoPack PRO v3.0.0 — 1-click setup for Linux (Ubuntu/Debian)
set -euo pipefail

NEO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"

echo "╔══════════════════════════════════════════╗"
echo "║      NeoPack PRO v3.0.0 Setup (Linux)  ║"
echo "║  48 Agents · 12 MCPs · 7 LSPs          ║"
echo "╚══════════════════════════════════════════╝"

# 1. Node.js
if ! command -v node &>/dev/null; then
    echo "Installing Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi
echo "✓ Node.js $(node --version)"

# 2. System deps
echo "Installing system dependencies..."
apt-get update
apt-get install -y git curl wget python3 python3-pip golang-go

# 3. OpenCode CLI
echo "Installing OpenCode CLI..."
npm install -g @opencode/cli

# 4. MCP Servers (PRO: all 12)
echo "Installing MCP Servers..."
MCP_PACKAGES=(
    "@anthropic/mcp-server-puppeteer"
    "@anthropic/mcp-server-playwright"
    "@anthropic/mcp-server-github"
    "@anthropic/mcp-server-brave-search"
    "@modelcontextprotocol/server-sequential-thinking"
    "@modelcontextprotocol/server-sqlite"
    "@modelcontextprotocol/server-memory"
    "@modelcontextprotocol/server-filesystem"
    "@modelcontextprotocol/server-postgres"
    "@modelcontextprotocol/server-redis"
    "@iflow-mcp/figma-mcp"
    "@notionhq/notion-mcp-server"
)
for pkg in "${MCP_PACKAGES[@]}"; do
    npm install -g "$pkg"
    echo "  ✓ $pkg"
done

# 5. LSPs
echo "Installing LSPs..."
npm install -g typescript-language-server vscode-langservers-extracted
pip3 install ruff

# 6. Formatters
echo "Installing Formatters..."
npm install -g prettier

# 7. Go tools
go install golang.org/x/tools/gopls@latest

# 8. Copy configs
echo "Copying configs..."
CONFIG_DIR="$HOME/.config/opencode"
mkdir -p "$CONFIG_DIR"
cp "$NEO_ROOT/config/opencode.jsonc" "$CONFIG_DIR/opencode.jsonc"

# 9. Init project
echo "Initializing NeoPack PRO project..."
PROJECT_DIR="$HOME/NeoPack-PRO"
mkdir -p "$PROJECT_DIR/.opencode"
cp -r "$NEO_ROOT/.opencode/agents" "$PROJECT_DIR/.opencode/"
cp "$NEO_ROOT/.opencode/opencode.json" "$PROJECT_DIR/.opencode/opencode.json"

# 10. Install Playwright browsers
npx playwright install chromium 2>/dev/null || true

echo ""
echo "╔══════════════════════════════════════════╗"
echo "║  NeoPack PRO v3.0.0 installed!         ║"
echo "║  cd ~/NeoPack-PRO                       ║"
echo "║  opencode                               ║"
echo "╚══════════════════════════════════════════╝"
