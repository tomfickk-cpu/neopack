<#
.SYNOPSIS
    Windsurf (Codeium) - Setup Completo com MCPs
#>

$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Windsurf IDE - Setup" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "[1/4] Configurando MCP Servers..." -ForegroundColor Yellow

$windsurfConfigDir = "$env:USERPROFILE\.codeium"
if (-not (Test-Path $windsurfConfigDir)) {
    New-Item -ItemType Directory -Path $windsurfConfigDir -Force | Out-Null
}

$mcpConfig = @{
    mcpServers = @{
        puppeteer = @{
            command = "npx"
            args = @("-y", "@anthropic/mcp-server-puppeteer", "--headless")
        }
        playwright = @{
            command = "npx"
            args = @("-y", "@anthropic/mcp-server-playwright")
        }
        github = @{
            command = "npx"
            args = @("-y", "@anthropic/mcp-server-github")
        }
        "brave-search" = @{
            command = "npx"
            args = @("-y", "@anthropic/mcp-server-brave-search")
        }
        "sequential-thinking" = @{
            command = "npx"
            args = @("-y", "@modelcontextprotocol/server-sequential-thinking")
        }
        sqlite = @{
            command = "npx"
            args = @("-y", "@modelcontextprotocol/server-sqlite")
        }
        memory = @{
            command = "npx"
            args = @("-y", "@modelcontextprotocol/server-memory")
        }
    }
}

$mcpConfig | ConvertTo-Json -Depth 10 | Set-Content "$windsurfConfigDir\windsurf_mcp_config.json"
Write-Host "  ✓ MCPs configurados" -ForegroundColor Green

Write-Host ""
Write-Host "[2/4] Configurando regras do projeto..." -ForegroundColor Yellow

$rules = @"
# Windsurf Rules
AI: Prefer local tools (grep, glob) before API calls.
Always analyze first, then modify.
Use free models as default.
"@

$rules | Set-Content "$windsurfConfigDir\rules.md"
Write-Host "  ✓ Regras configuradas" -ForegroundColor Green

Write-Host ""
Write-Host "[3/4] Instalando infraestrutura..." -ForegroundColor Yellow
npm install -g vscode-langservers-extracted 2>&1 | Out-Null
pip install ruff pandas numpy openpyxl 2>&1 | Out-Null
Write-Host "  ✓ LSPs e pacotes Python instalados" -ForegroundColor Green

Write-Host ""
Write-Host "[4/4] Instalando MCPs via npx..." -ForegroundColor Yellow
npx -y @anthropic/mcp-server-puppeteer --version 2>&1 | Out-Null
npx -y @anthropic/mcp-server-playwright --version 2>&1 | Out-Null
npx -y @modelcontextprotocol/server-sequential-thinking --version 2>&1 | Out-Null
Write-Host "  ✓ MCPs instalados" -ForegroundColor Green

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  SETUP WINDSURF CONCLUÍDO!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
