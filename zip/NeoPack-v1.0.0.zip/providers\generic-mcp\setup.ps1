<#
.SYNOPSIS
    Generic MCP Setup - Para qualquer ferramenta compatível com MCP
.DESCRIPTION
    Instala todos MCPs globalmente e gera configs em JSON
    para usar em qualquer ferramenta (VS Code, Cursor, Claude, etc.)
#>

$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Generic MCP Setup" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "[1/3] Instalando MCP Servers..." -ForegroundColor Yellow

$mcps = @(
    @{Name="puppeteer"; Pkg="@anthropic/mcp-server-puppeteer"; Args=@("--headless")},
    @{Name="playwright"; Pkg="@anthropic/mcp-server-playwright"; Args=@()},
    @{Name="github"; Pkg="@anthropic/mcp-server-github"; Args=@()},
    @{Name="brave-search"; Pkg="@anthropic/mcp-server-brave-search"; Args=@()},
    @{Name="sequential-thinking"; Pkg="@modelcontextprotocol/server-sequential-thinking"; Args=@()},
    @{Name="sqlite"; Pkg="@modelcontextprotocol/server-sqlite"; Args=@()},
    @{Name="memory"; Pkg="@modelcontextprotocol/server-memory"; Args=@()},
    @{Name="filesystem"; Pkg="@modelcontextprotocol/server-filesystem"; Args=@()}
)

foreach ($mcp in $mcps) {
    Write-Host "  Instalando $($mcp.Name)..." -ForegroundColor Gray
    npx -y $($mcp.Pkg) --version 2>&1 | Out-Null
    Write-Host "  ✓ $($mcp.Name)" -ForegroundColor Green
}

Write-Host ""
Write-Host "[2/3] Gerando config universal..." -ForegroundColor Yellow

$mcpConfig = @{}
foreach ($mcp in $mcps) {
    $mcpConfig[$mcp.Name] = @{
        command = "npx"
        args = @("-y", $mcp.Pkg) + $mcp.Args
    }
}

$output = @{ mcpServers = $mcpConfig }
$output | ConvertTo-Json -Depth 10 | Set-Output "$PWD\mcp-config.json"
Write-Host "  ✓ Config gerada: $PWD\mcp-config.json" -ForegroundColor Green

Write-Host ""
Write-Host "[3/3] Instalando infraestrutura..." -ForegroundColor Yellow
npm install -g vscode-langservers-extracted 2>&1 | Out-Null
pip install ruff pandas numpy openpyxl 2>&1 | Out-Null
Write-Host "  ✓ LSPs e pacotes Python" -ForegroundColor Green

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  GENERIC MCP SETUP CONCLUÍDO!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Arquivo de config gerado: mcp-config.json" -ForegroundColor White
Write-Host ""
Write-Host "Para usar em qualquer ferramenta:" -ForegroundColor Cyan
Write-Host "  VS Code + Continue: copie mcpServers para .continue/mcp.json"
Write-Host "  Cursor: copie mcpServers para .cursor/mcp.json"
Write-Host "  Claude Desktop: copie para claude_desktop_config.json"
Write-Host "  Windsurf: copie para .codeium/windsurf_mcp_config.json"
