<#
.SYNOPSIS
    VS Code + Continue - Setup Completo
.DESCRIPTION
    VS Code com extensão Continue (open-source AI coding)
    + todos MCPs, LSPs e formatters configurados
#>

$ErrorActionPreference = "Stop"
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  VS Code + Continue - Setup" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# === 1. VERIFICAR VS CODE ===
Write-Host "[1/7] Verificando VS Code..." -ForegroundColor Yellow
$codePath = Get-Command code -ErrorAction SilentlyContinue
if (-not $codePath) {
    Write-Host "  ✗ VS Code não encontrado no PATH" -ForegroundColor Red
    Write-Host "  Instale em: https://code.visualstudio.com" -ForegroundColor Yellow
    $continue = Read-Host "Deseja continuar mesmo assim? (s/N)"
    if ($continue -ne "s") { exit 1 }
} else {
    Write-Host "  ✓ VS Code encontrado" -ForegroundColor Green
}

# === 2. INSTALAR EXTENSÕES VS CODE ===
Write-Host ""
Write-Host "[2/7] Instalando extensões VS Code..." -ForegroundColor Yellow

$extensions = @(
    "continue.continue",                    # Continue AI
    "github.copilot",                       # GitHub Copilot (opcional)
    "github.copilot-chat",                  # Copilot Chat
    "ms-python.python",                     # Python
    "golang.go",                            # Go
    "esbenp.prettier-vscode",              # Prettier
    "charliermarsh.ruff",                  # Ruff
    "dbaeumer.vscode-eslint",              # ESLint
    "ritwickdey.liveserver"                # Live Server
)

if ($codePath) {
    foreach ($ext in $extensions) {
        try {
            code --install-extension $ext --force 2>&1 | Out-Null
            Write-Host "  ✓ $ext" -ForegroundColor Green
        } catch {
            Write-Host "  ✗ Falha ao instalar $ext" -ForegroundColor Red
        }
    }
}

# === 3. CONFIGURAR CONTINUE ===
Write-Host ""
Write-Host "[3/7] Configurando Continue..." -ForegroundColor Yellow

$continueConfigDir = "$env:USERPROFILE\.continue"
if (-not (Test-Path $continueConfigDir)) {
    New-Item -ItemType Directory -Path $continueConfigDir -Force | Out-Null
}

$continueConfig = @{
    models = @(
        @{
            title = "DeepSeek V4 Flash"
            provider = "openai"
            model = "deepseek-v4-flash"
            apiBase = "https://opencode.ai/zen/v1"
            apiKey = "SEU_API_KEY_AQUI"
        },
        @{
            title = "Qwen 3.7 Plus (Go)"
            provider = "openai"
            model = "qwen3.7-plus"
            apiBase = "https://opencode.ai/zen/go/v1"
            apiKey = "SEU_API_KEY_GO_AQUI"
        }
    )
    tabAutocompleteModel = @{
        title = "DeepSeek V4 Flash"
        provider = "openai"
        model = "deepseek-v4-flash"
        apiBase = "https://opencode.ai/zen/v1"
        apiKey = "SEU_API_KEY_AQUI"
    }
    contextProviders = @(
        @{ name = "codebase" },
        @{ name = "open" },
        @{ name = "terminal" },
        @{ name = "problems" },
        @{ name = "folder" }
    )
    slashCommands = @(
        @{ name = "edit"; description = "Edit highlighted code" },
        @{ name = "comment"; description = "Add comments" },
        @{ name = "share"; description = "Share session" },
        @{ name = "commit"; description = "Generate commit message" }
    )
    experimental = @{
        modelRunner = "openai"
    }
}

$continueConfig | ConvertTo-Json -Depth 10 | Set-Content "$continueConfigDir\config.json"
Write-Host "  ✓ Continue configurado" -ForegroundColor Green

# === 4. CONFIG MCP NO CONTINUE ===
Write-Host ""
Write-Host "[4/7] Configurando MCP Servers para Continue..." -ForegroundColor Yellow

$mcpConfig = @{
    mcpServers = @{
        puppeteer = @{
            command = "npx"
            args = @("@anthropic/mcp-server-puppeteer", "--headless")
        }
        playwright = @{
            command = "npx"
            args = @("@anthropic/mcp-server-playwright")
        }
        github = @{
            command = "npx"
            args = @("@anthropic/mcp-server-github")
        }
        "brave-search" = @{
            command = "npx"
            args = @("@anthropic/mcp-server-brave-search")
        }
        "sequential-thinking" = @{
            command = "npx"
            args = @("@modelcontextprotocol/server-sequential-thinking")
        }
        memory = @{
            command = "npx"
            args = @("@modelcontextprotocol/server-memory")
        }
    }
}

$mcpConfig | ConvertTo-Json -Depth 10 | Set-Content "$continueConfigDir\mcp.json"
Write-Host "  ✓ MCPs configurados" -ForegroundColor Green

# === 5. VS CODE SETTINGS ===
Write-Host ""
Write-Host "[5/7] Configurando VS Code settings..." -ForegroundColor Yellow

$vscodeSettingsDir = "$env:APPDATA\Code\User"
if (-not (Test-Path $vscodeSettingsDir)) {
    New-Item -ItemType Directory -Path $vscodeSettingsDir -Force | Out-Null
}

$settings = @{
    "editor.formatOnSave" = $true
    "editor.defaultFormatter" = "esbenp.prettier-vscode"
    "[python]" = @{
        "editor.defaultFormatter" = "charliermarsh.ruff"
    }
    "[go]" = @{
        "editor.defaultFormatter" = "golang.go"
    }
    "continue.showDebugOutput" = $false
    "continue.allowAnonymousTelemetry" = $false
    "continue.enableTabAutocomplete" = $true
    "git.enableSmartCommit" = $true
    "files.autoSave" = "onFocusChange"
}

$settings | ConvertTo-Json -Depth 10 | Set-Content "$vscodeSettingsDir\settings.json"
Write-Host "  ✓ VS Code settings configurados" -ForegroundColor Green

# === 6. INSTALAR INFRA COMPARTILHADA ===
Write-Host ""
Write-Host "[6/7] Instalando infraestrutura compartilhada..." -ForegroundColor Yellow

# Pacotes npm
npm install -g vscode-langservers-extracted 2>&1 | Out-Null
Write-Host "  ✓ LSPs npm instalados" -ForegroundColor Green

# Pacotes Python
pip install ruff pandas numpy openpyxl 2>&1 | Out-Null
Write-Host "  ✓ Pacotes Python instalados" -ForegroundColor Green

# === 7. AGENTES COMO PROMPTS ===
Write-Host ""
Write-Host "[7/7] Copiando prompts dos agentes..." -ForegroundColor Yellow

$agentsSrc = Join-Path (Split-Path $ScriptPath -Parent) "..\agents"
$agentsDst = "$env:USERPROFILE\.continue\agents"
if (Test-Path $agentsSrc) {
    if (-not (Test-Path $agentsDst)) {
        New-Item -ItemType Directory -Path $agentsDst -Force | Out-Null
    }
    Copy-Item "$agentsSrc\*.md" $agentsDst -Force
    Write-Host "  ✓ Prompts copiados para: $agentsDst" -ForegroundColor Green
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  SETUP VS CODE + CONTINUE CONCLUÍDO!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Próximos passos:" -ForegroundColor White
Write-Host "  1. Abra o VS Code"
Write-Host "  2. Configure suas API keys no arquivo:"
Write-Host "     $env:USERPROFILE\.continue\config.json"
Write-Host "  3. Use Ctrl+Shift+P > Continue: Open Config"
Write-Host "  4. Comece a usar a AI com MCPs prontos!"
