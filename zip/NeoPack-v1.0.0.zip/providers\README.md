# OpenCode Config Pack - Multi-Provider

Pacote completo de configura��o para 6 ferramentas de AI coding.

## Ferramentas Suportadas

| Ferramenta | Setup |
|------------|-------|
| **OpenCode** | setup.ps1 (raiz) |
| **VS Code + Continue** | providers/vscode-continue/setup.ps1 |
| **VS Code + GitHub Copilot** | providers/vscode-copilot/setup.ps1 |
| **Cursor** | providers/cursor/setup.ps1 |
| **Claude Desktop** | providers/claude-desktop/setup.ps1 |
| **Windsurf (Codeium)** | providers/windsurf/setup.ps1 |
| **Generic MCP** | providers/generic-mcp/setup.ps1 |

## Infraestrutura Compartilhada

Todas as vers�es incluem:

### 8 MCP Servers
Puppeteer, Playwright, GitHub, Brave Search,
Sequential Thinking, SQLite, Memory, Filesystem

### 7 LSPs
Go, TypeScript, HTML, CSS, JSON, Python (ruff), Markdown

### 3 Formatters
Go (gofmt), Web (prettier), Python (ruff)

### Python Data Stack
pandas, numpy, openpyxl

## Como usar

1. Escolha a ferramenta desejada
2. Execute o setup.ps1 como Administrador
3. Configure as API keys quando solicitado
4. Pronto!
