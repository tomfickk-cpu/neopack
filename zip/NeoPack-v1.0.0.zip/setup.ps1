<#
.SYNOPSIS
    OpenCode Configuration Pack - Setup Automatizado
.DESCRIPTION
    Instala todas as ferramentas, configurações e agentes do OpenCode
    em um novo computador. Execute como Administrador.
#>

$ErrorActionPreference = "Stop"
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
$ConfigsPath = Join-Path $ScriptPath "configs"
$AgentsPath = Join-Path $ScriptPath "agents"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  OpenCode Config Pack - Setup" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# === 1. VERIFICAR PRÉ-REQUISITOS ===
Write-Host "[1/6] Verificando pré-requisitos..." -ForegroundColor Yellow

$prereqs = @(
    @{Name="Node.js"; Cmd="node --version"},
    @{Name="Python"; Cmd="python --version"},
    @{Name="Go"; Cmd="go version"},
    @{Name="Git"; Cmd="git --version"}
)

$allOk = $true
foreach ($p in $prereqs) {
    try {
        $ver = Invoke-Expression $p.Cmd 2>&1
        Write-Host "  ✓ $($p.Name): $ver" -ForegroundColor Green
    } catch {
        Write-Host "  ✗ $($p.Name): NÃO ENCONTRADO" -ForegroundColor Red
        $allOk = $false
    }
}

if (-not $allOk) {
    Write-Host ""
    Write-Host "Instale os pré-requisitos faltantes e tente novamente:" -ForegroundColor Red
    Write-Host "  Node.js: https://nodejs.org" 
    Write-Host "  Python:  https://python.org"
    Write-Host "  Go:      https://go.dev"
    Write-Host "  Git:     https://git-scm.com"
    exit 1
}

# === 2. INSTALAR PACOTES NPM GLOBAIS ===
Write-Host ""
Write-Host "[2/6] Instalando pacotes npm globais..." -ForegroundColor Yellow

$npmPackages = @(
    "opencode-ai",
    "vscode-langservers-extracted"
)

foreach ($pkg in $npmPackages) {
    Write-Host "  Instalando $pkg..." -ForegroundColor Gray
    npm install -g $pkg 2>&1 | Out-Null
    Write-Host "  ✓ $pkg instalado" -ForegroundColor Green
}

# === 3. INSTALAR PACOTES PYTHON ===
Write-Host ""
Write-Host "[3/6] Instalando pacotes Python..." -ForegroundColor Yellow

$pipPackages = @(
    "ruff",
    "pandas",
    "numpy",
    "openpyxl"
)

foreach ($pkg in $pipPackages) {
    Write-Host "  Instalando $pkg..." -ForegroundColor Gray
    pip install $pkg 2>&1 | Out-Null
    Write-Host "  ✓ $pkg instalado" -ForegroundColor Green
}

# === 4. CONFIGURAR PASTAS ===
Write-Host ""
Write-Host "[4/6] Configurando pastas..." -ForegroundColor Yellow

# Pasta de config global
$globalConfigDir = "$env:USERPROFILE\.config\opencode"
if (-not (Test-Path $globalConfigDir)) {
    New-Item -ItemType Directory -Path $globalConfigDir -Force | Out-Null
    Write-Host "  ✓ Criado: $globalConfigDir" -ForegroundColor Green
}

# Copiar config global
$globalConfigSrc = Join-Path $ConfigsPath "opencode.global.jsonc"
$globalConfigDst = Join-Path $globalConfigDir "opencode.jsonc"
Copy-Item $globalConfigSrc $globalConfigDst -Force
Write-Host "  ✓ Config global copiada" -ForegroundColor Green

# Perguntar pelo diretório do projeto
$projPath = Read-Host "`nCaminho do projeto (Enter para pular): "
if ($projPath -and (Test-Path $projPath)) {
    $projOpenCode = Join-Path $projPath ".opencode"
    if (-not (Test-Path $projOpenCode)) {
        New-Item -ItemType Directory -Path $projOpenCode -Force | Out-Null
    }
    
    # Copiar config do projeto
    $projConfigSrc = Join-Path $ConfigsPath "opencode.project.json"
    $projConfigDst = Join-Path $projOpenCode "opencode.json"
    Copy-Item $projConfigSrc $projConfigDst -Force
    
    # Copiar agentes
    $projAgents = Join-Path $projOpenCode "agents"
    if (-not (Test-Path $projAgents)) {
        New-Item -ItemType Directory -Path $projAgents -Force | Out-Null
    }
    Copy-Item "$AgentsPath\*.md" $projAgents -Force
    
    Write-Host "  ✓ Config do projeto copiada para: $projOpenCode" -ForegroundColor Green
}

# === 5. INSTALAR MCP SERVERS ===
Write-Host ""
Write-Host "[5/6] Instalando MCP Servers..." -ForegroundColor Yellow

$mcpServers = @(
    @{Name="puppeteer"; Cmd="npx @anthropic/mcp-server-puppeteer --headless"},
    @{Name="playwright"; Cmd="npx @anthropic/mcp-server-playwright"},
    @{Name="github"; Cmd="npx @anthropic/mcp-server-github"},
    @{Name="brave-search"; Cmd="npx @anthropic/mcp-server-brave-search"},
    @{Name="sequential-thinking"; Cmd="npx @modelcontextprotocol/server-sequential-thinking"},
    @{Name="memory"; Cmd="npx @modelcontextprotocol/server-memory"}
)

foreach ($mcp in $mcpServers) {
    Write-Host "  Adicionando $($mcp.Name)..." -ForegroundColor Gray
    opencode mcp add $($mcp.Name) -- $($mcp.Cmd) 2>&1 | Out-Null
    Write-Host "  ✓ $($mcp.Name) adicionado" -ForegroundColor Green
}

# SQLite e Filesystem precisam de caminho
Write-Host ""
Write-Host "  MCPs que precisam de caminho personalizado:" -ForegroundColor Yellow
$sqlitePath = Read-Host "  Caminho do banco SQLite (ex: C:\projeto\data.db)"
if ($sqlitePath) {
    opencode mcp add sqlite -- npx @modelcontextprotocol/server-sqlite "`"$sqlitePath`"" 2>&1 | Out-Null
    Write-Host "  ✓ SQLite configurado" -ForegroundColor Green
}

$fsPath = Read-Host "  Caminho raiz do projeto para Filesystem"
if ($fsPath) {
    opencode mcp add filesystem -- npx @modelcontextprotocol/server-filesystem "`"$fsPath`"" 2>&1 | Out-Null
    Write-Host "  ✓ Filesystem configurado" -ForegroundColor Green
}

# === 6. AUTENTICAÇÃO ===
Write-Host ""
Write-Host "[6/6] Configurar autenticação..." -ForegroundColor Yellow
Write-Host "  Você precisa autenticar os provedores:" -ForegroundColor White
Write-Host "  opencode auth login --provider opencode --method api"
Write-Host "  opencode auth login --provider opencode-go --method api"
Write-Host ""
Write-Host "  Suas chaves de API em: https://opencode.ai/auth" -ForegroundColor Cyan

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  SETUP CONCLUÍDO!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Próximos passos:" -ForegroundColor White
Write-Host "  1. Autentique os provedores (comando acima)"
Write-Host "  2. Abra o OpenCode: opencode"
Write-Host "  3. Configure os plugins: opencode plugin @op1/code-graph"
Write-Host "  4. Aproveite! Todas as ferramentas e agentes prontos."
Write-Host ""
Write-Host "Para mais detalhes, veja: docs/SETUP_GUIDE.md" -ForegroundColor Cyan
