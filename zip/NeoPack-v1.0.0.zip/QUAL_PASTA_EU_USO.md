# QUAL PASTA USAR?

Responda as perguntas abaixo para descobrir a pasta certa:

## 1. Você usa qual ferramenta para programar?

| Você usa... | ➡ Vá para |
|-------------|-----------|
| **OpenCode** (CLI ou Desktop) | `setup.ps1` (raiz) |
| **VS Code** | vá para pergunta 2 |
| **Cursor** | `providers/cursor/` |
| **Claude Desktop** | `providers/claude-desktop/` |
| **Windsurf** | `providers/windsurf/` |
| **Outra ferramenta** | `providers/generic-mcp/` |

## 2. Você usa VS Code. Qual extensão de IA?

| Você usa... | ➡ Vá para |
|-------------|-----------|
| **Continue** (gratuito, open-source) | `providers/vscode-continue/` |
| **GitHub Copilot** (assinatura Microsoft) | `providers/vscode-copilot/` |
| **Nenhuma das duas** | `providers/generic-mcp/` |

## Resumo rápido

```
Qual editor você usa?
│
├─ OpenCode → setup.ps1 (raiz)
│
├─ VS Code
│   ├─ Continue → providers/vscode-continue/
│   └─ Copilot → providers/vscode-copilot/
│
├─ Cursor → providers/cursor/
│
├─ Claude Desktop → providers/claude-desktop/
│
├─ Windsurf → providers/windsurf/
│
└─ Outro → providers/generic-mcp/
```

## Ainda na dúvida?

| Se você... | Pasta recomendada |
|------------|-------------------|
| Não sabe qual IA usa | `providers/generic-mcp/` (instala só os MCPs, você configura depois) |
| Quer a configuração mais completa | `setup.ps1` (raiz) — OpenCode tem 14 agentes + mais recursos |
| Quer algo gratuito e simples | `providers/vscode-continue/` |
| Já paga GitHub Copilot | `providers/vscode-copilot/` |
