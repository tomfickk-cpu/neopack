<#
.SYNOPSIS
    Cursor Editor - Setup Completo
.DESCRIPTION
    Cursor (AI-native IDE) com todos MCPs, regras e configurações
#>

$ErrorActionPreference = "Stop"
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Cursor Editor - Setup" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# === 1. VERIFICAR CURSOR ===
Write-Host "[1/6] Verificando Cursor..." -ForegroundColor Yellow
$cursorPath = "$env:LOCALAPPS\Programs\Cursor\Cursor.exe"
if (-not (Test-Path $cursorPath)) {
    Write-Host "  ⚠ Cursor não encontrado em $cursorPath" -ForegroundColor Yellow
    Write-Host "  Instale em: https://cursor.sh" -ForegroundColor Yellow
} else {
    Write-Host "  ✓ Cursor encontrado" -ForegroundColor Green
}

# === 2. CONFIG MCP (global do Cursor) ===
Write-Host ""
Write-Host "[2/6] Configurando MCP Servers..." -ForegroundColor Yellow

$cursorConfigDir = "$env:USERPROFILE\.cursor"
if (-not (Test-Path $cursorConfigDir)) {
    New-Item -ItemType Directory -Path $cursorConfigDir -Force | Out-Null
}

$mcpConfig = @{
    mcpServers = @{
        puppeteer = @{
            command = "npx"
            args = @("@anthropic/mcp-server-puppeteer", "--headless")
        }
        playwright = @{
            command = "npx"
            args = @("@anthropic/mcp-server-playwright")
        }
        github = @{
            command = "npx"
            args = @("@anthropic/mcp-server-github")
        }
        "brave-search" = @{
            command = "npx"
            args = @("@anthropic/mcp-server-brave-search")
        }
        "sequential-thinking" = @{
            command = "npx"
            args = @("@modelcontextprotocol/server-sequential-thinking")
        }
        sqlite = @{
            command = "npx"
            args = @("@modelcontextprotocol/server-sqlite")
        }
        memory = @{
            command = "npx"
            args = @("@modelcontextprotocol/server-memory")
        }
        filesystem = @{
            command = "npx"
            args = @("@modelcontextprotocol/server-filesystem")
        }
    }
}

$mcpConfig | ConvertTo-Json -Depth 10 | Set-Content "$cursorConfigDir\mcp.json"
Write-Host "  ✓ MCPs configurados" -ForegroundColor Green

# === 3. REGRAS GLOBAIS DO CURSOR ===
Write-Host ""
Write-Host "[3/6] Configurando regras do Cursor..." -ForegroundColor Yellow

$rules = @"
You are an expert developer assistant for the user's projects.

## Core Rules
1. ALWAYS use local tools (grep, glob, search) before making changes — zero cost
2. Prefer efficient analysis over brute-force reading
3. Use free AI models by default, only upgrade to paid when necessary
4. Each task has the right specialized approach

## Available MCP Servers
- puppeteer: Headless browser testing
- playwright: Advanced browser automation
- github: Git, PRs, issues
- brave-search: Web search
- sequential-thinking: Step-by-step reasoning
- sqlite: Local database
- memory: Persistent context across sessions
- filesystem: Sandboxed file operations

## Agents (use as prompts)
- web-dev: HTML/CSS/JS web projects
- image-processor: Image validation and processing
- content-mapper: Content sync between formats
- build-assistant: Build, lint, test automation
- code-review: Code quality analysis
- data-pipeline: Data transformation (pandas, SQL)
- seo-qa: SEO and accessibility review
- pdf-processor: PDF extraction
- db-agent: SQLite management
- script-automation: Build/deploy scripts
- go-dev: Go development
"@

$rules | Set-Content "$cursorConfigDir\rules.txt"
Write-Host "  ✓ Regras configuradas" -ForegroundColor Green

# === 4. PROMPTS DOS AGENTES ===
Write-Host ""
Write-Host "[4/6] Copiando prompts dos agentes..." -ForegroundColor Yellow
$agentsSrc = Join-Path (Split-Path $ScriptPath -Parent) "..\agents"
$agentsDst = "$cursorConfigDir\agents"
if (Test-Path $agentsSrc) {
    if (-not (Test-Path $agentsDst)) {
        New-Item -ItemType Directory -Path $agentsDst -Force | Out-Null
    }
    Copy-Item "$agentsSrc\*.md" $agentsDst -Force
    Write-Host "  ✓ Prompts copiados" -ForegroundColor Green
}

# === 5. INFRA COMPARTILHADA ===
Write-Host ""
Write-Host "[5/6] Instalando infraestrutura..." -ForegroundColor Yellow
npm install -g vscode-langservers-extracted 2>&1 | Out-Null
pip install ruff pandas numpy openpyxl 2>&1 | Out-Null
Write-Host "  ✓ LSPs e pacotes Python instalados" -ForegroundColor Green

# === 6. VS CODE SETTINGS (Cursor usa compatível) ===
Write-Host ""
Write-Host "[6/6] Configurando editor settings..." -ForegroundColor Yellow

$vscodeSettingsDir = "$env:APPDATA\Cursor\User"
if (-not (Test-Path $vscodeSettingsDir)) {
    New-Item -ItemType Directory -Path $vscodeSettingsDir -Force | Out-Null
}

$settings = @{
    "editor.formatOnSave" = $true
    "editor.defaultFormatter" = "esbenp.prettier-vscode"
    "[python]" = @{ "editor.defaultFormatter" = "charliermarsh.ruff" }
    "[go]" = @{ "editor.defaultFormatter" = "golang.go" }
    "files.autoSave" = "onFocusChange"
}

$settings | ConvertTo-Json -Depth 10 | Set-Content "$vscodeSettingsDir\settings.json"
Write-Host "  ✓ Settings configurados" -ForegroundColor Green

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  SETUP CURSOR CONCLUÍDO!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Próximos passos:" -ForegroundColor White
Write-Host "  1. Abra o Cursor"
Write-Host "  2. Vá em Settings > Cursor Settings > MCP"
Write-Host "  3. Os MCPs já estão configurados"
Write-Host "  4. Configure suas API keys nos provedores"
Write-Host "  5. Regras em: $cursorConfigDir\rules.txt"
