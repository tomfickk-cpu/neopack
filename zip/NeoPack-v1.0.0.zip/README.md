# 🚀 OpenCode Config Pack

Pacote portátil de configuração máxima para OpenCode.

## Conteúdo

```
opencode-config-pack/
├── setup.ps1              # Instalador automático
├── README.md              # Este arquivo
├── configs/
│   ├── opencode.global.jsonc   # Config global (LSPs, MCPs, formatters)
│   ├── opencode.project.json   # Config projeto (agentes, plugins)
│   ├── opencode.teste.json     # Config workspace teste
│   └── auth.template.json      # Template de autenticação
├── agents/
│   ├── build-assistant.md
│   ├── code-review.md
│   ├── content-mapper.md
│   ├── data-pipeline.md
│   ├── db-agent.md
│   ├── go-dev.md
│   ├── image-processor.md
│   ├── pdf-processor.md
│   ├── script-automation.md
│   ├── seo-qa.md
│   └── web-dev.md
├── docs/
│   ├── SETUP_GUIDE.md         # Guia de instalação detalhado
│   └── AGENTS_REFERENCE.md    # Referência completa dos agentes
└── requirements/
    └── tools.json             # Manifesto de ferramentas necessárias
```

## Como usar

### 1. Instalação automática
```powershell
# Execute como Administrador
.\setup.ps1
```

### 2. Manual
Siga o guia em `docs/SETUP_GUIDE.md`

### 3. Em qualquer PC
1. Copie esta pasta para o novo computador
2. Instale Node.js, Python, Go e Git
3. Execute `setup.ps1` como Administrador
4. Cole suas chaves de API

## Requisitos mínimos
- Windows 10/11
- Node.js 18+
- Python 3.10+
- Go 1.21+
- Git 2.30+
- 500MB de espaço em disco
- Acesso à internet para instalação

## Licença
Configuração livre para uso em qualquer projeto.
