# PLATAFORMAS ATENDIDAS PELO PACOTE

## 📦 opencode-config-pack.zip

Este pacote contém configurações completas (MCPs, LSPs, formatters, agentes)
para as seguintes plataformas:

---

### 1️⃣ OpenCode
- **Pasta:** `setup.ps1` (raiz)
- **O que é:** CLI + Desktop nativo do OpenCode
- **Requer:** Node.js, Python, Go, Git
- **Diferencial:** Setup completo com todos os 11 agentes, 8 MCPs, 7 LSPs

### 2️⃣ VS Code + Continue
- **Pasta:** `providers/vscode-continue/setup.ps1`
- **O que é:** Extensão open-source de IA para VS Code
- **Requer:** VS Code, Node.js, Python
- **Diferencial:** Gratuito, configurável, suporta MCPs nativamente

### 3️⃣ VS Code + GitHub Copilot
- **Pasta:** `providers/vscode-copilot/setup.ps1`
- **O que é:** IA nativa do VS Code (assinatura)
- **Requer:** VS Code, assinatura GitHub Copilot
- **Diferencial:** Autocomplete inline + chat integrado

### 4️⃣ Cursor
- **Pasta:** `providers/cursor/setup.ps1`
- **O que é:** Editor IA-native (baseado em VS Code)
- **Requer:** Cursor Editor, Node.js, Python
- **Diferencial:** IA integrada no editor, suporta MCPs

### 5️⃣ Claude Desktop
- **Pasta:** `providers/claude-desktop/setup.ps1`
- **O que é:** Aplicativo desktop da Anthropic
- **Requer:** Claude Desktop, assinatura Anthropic
- **Diferencial:** Suporte nativo a MCPs pela Anthropic

### 6️⃣ Windsurf (Codeium)
- **Pasta:** `providers/windsurf/setup.ps1`
- **O que é:** IDE IA da Codeium
- **Requer:** Windsurf IDE, Node.js, Python
- **Diferencial:** IA integrada + MCPs

### 7️⃣ Generic MCP
- **Pasta:** `providers/generic-mcp/setup.ps1`
- **O que é:** Para QUALQUER ferramenta que suporte MCP
- **Requer:** Node.js, Python
- **Diferencial:** Gera config universal para adaptar manualmente

---

## Infraestrutura Compartilhada (todas as plataformas)

Independente da plataforma escolhida, todas instalam:

| Categoria | Itens |
|-----------|-------|
| **MCP Servers** | Puppeteer, Playwright, GitHub, Brave Search, Sequential Thinking, SQLite, Memory, Filesystem |
| **LSPs** | Go, TypeScript, HTML, CSS, JSON, Python (ruff), Markdown |
| **Formatters** | Prettier (web), Ruff (Python), Gofmt (Go) |
| **Python** | pandas, numpy, openpyxl |

## Como usar

1. Extraia o ZIP
2. Escolha a pasta da plataforma desejada
3. Execute `setup.ps1` como **Administrador**
4. Configure as chaves de API quando solicitado
5. Pronto!

## Requisitos mínimos

- Windows 10/11
- Node.js 18+
- Python 3.10+
- Git 2.30+
- A ferramenta escolhida instalada (VS Code, Cursor, etc.)
