<#
.SYNOPSIS
    VS Code + GitHub Copilot - Setup Completo
#>

$ErrorActionPreference = "Stop"

Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  VS Code + GitHub Copilot - Setup" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

$codePath = Get-Command code -ErrorAction SilentlyContinue
if (-not $codePath) {
    Write-Host "✗ VS Code não encontrado. Instale: https://code.visualstudio.com" -ForegroundColor Red
    exit 1
}

Write-Host "[1/4] Instalando extensões VS Code..." -ForegroundColor Yellow
$extensions = @(
    "github.copilot",
    "github.copilot-chat",
    "ms-python.python",
    "golang.go",
    "esbenp.prettier-vscode",
    "charliermarsh.ruff"
)
foreach ($ext in $extensions) {
    code --install-extension $ext --force 2>&1 | Out-Null
    Write-Host "  ✓ $ext" -ForegroundColor Green
}

Write-Host ""
Write-Host "[2/4] Configurando VS Code settings..." -ForegroundColor Yellow
$vscodeSettingsDir = "$env:APPDATA\Code\User"
if (-not (Test-Path $vscodeSettingsDir)) {
    New-Item -ItemType Directory -Path $vscodeSettingsDir -Force | Out-Null
}
$settings = @{
    "editor.formatOnSave" = $true
    "editor.defaultFormatter" = "esbenp.prettier-vscode"
    "[python]" = @{ "editor.defaultFormatter" = "charliermarsh.ruff" }
    "[go]" = @{ "editor.defaultFormatter" = "golang.go" }
    "github.copilot.enable" = @{ "*" = $true }
    "github.copilot.editor.enableAutoCompletions" = $true
    "files.autoSave" = "onFocusChange"
}
$settings | ConvertTo-Json -Depth 10 | Set-Content "$vscodeSettingsDir\settings.json"
Write-Host "  ✓ Settings configurados" -ForegroundColor Green

Write-Host ""
Write-Host "[3/4] Instalando infraestrutura..." -ForegroundColor Yellow
npm install -g vscode-langservers-extracted 2>&1 | Out-Null
pip install ruff pandas numpy openpyxl 2>&1 | Out-Null
Write-Host "  ✓ LSPs e pacotes Python" -ForegroundColor Green

Write-Host ""
Write-Host "[4/4] Configurando prompts Copilot..." -ForegroundColor Yellow
$copilotDir = "$env:USERPROFILE\.github\copilot"
if (-not (Test-Path $copilotDir)) {
    New-Item -ItemType Directory -Path $copilotDir -Force | Out-Null
}

$instructions = @"
You are an expert developer assistant.

## Rules
1. Always analyze code first, then suggest changes
2. Use simple, efficient solutions by default
3. Prefer free approaches over paid API calls
4. Keep code clean and well-structured

## Available tools (via VS Code)
- Terminal commands (npm, pip, git, etc.)
- Integrated debugging
- Live preview (Live Server extension)
"@

$instructions | Set-Content "$copilotDir\instructions.md"
Write-Host "  ✓ Prompt configurado" -ForegroundColor Green

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  SETUP VS CODE + COPILOT CONCLUÍDO!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Próximos passos:" -ForegroundColor White
Write-Host "  1. Abra o VS Code"
Write-Host "  2. Faça login no GitHub Copilot (Ctrl+Shift+P > Sign in to Copilot)"
Write-Host "  3. Comece a codar com AI inline e chat"
