# Referência Completa de Agentes

## AGENTES DE ANÁLISE (zero crédito)

### explore
- **Tipo:** Built-in (ferramentas locais)
- **Custo:** ZERO
- **Tarefas:** Buscar arquivos (glob), pesquisar conteúdo (grep), explorar estrutura de diretórios, responder perguntas sobre o código

### code-review
- **Prompt:** `agents/code-review.md`
- **Custo:** Gratuito (modelo padrão)
- **Tarefas:**
  - Análise de qualidade (HTML, CSS, JS, Python, Go)
  - Detecta problemas de segurança (XSS, injeção)
  - Verifica performance (loops ineficientes, assets pesados)
  - Valida boas práticas por linguagem
  - Gera relatório com issues priorizadas + correções
- **Saída:** `code-review-report.md`

## AGENTES DO PROJETO WEB

### web-dev
- **Prompt:** `agents/web-dev.md`
- **Custo:** Gratuito (modelo padrão)
- **Tarefas:**
  - Editar HTML/CSS/JS de sites
  - Manipular DOM, CSS Grid/Flexbox, estilos inline
  - Substituir assets de imagem (pagina_NN.jpg → receita-NN.jpg)
  - Ajustar layout mobile-first
  - Trabalhar com HTML minificado
- **Arquivos-alvo:** HTML, CSS, JS

### image-processor
- **Prompt:** `agents/image-processor.md`
- **Custo:** Gratuito (modelo padrão)
- **Tarefas:**
  - Varrer diretórios de imagens
  - Detectar/resolver duplicatas por hash
  - Normalizar nomes de arquivo
  - Converter formatos e redimensionar (2:3)
  - Validar tamanho mínimo (240KB)
  - Gerar relatório de limpeza
- **Saída:** `image_map.csv`, `hash_report.txt`, `image_processor.py`

### content-mapper
- **Prompt:** `agents/content-mapper.md`
- **Custo:** Gratuito (modelo padrão)
- **Tarefas:**
  - Rastrear links entre HTML, PDF, imagens e scripts
  - Detectar inconsistências entre diretórios
  - Gerar mapeamentos automáticos
  - Validar referências cruzadas
  - Identificar links quebrados
- **Saída:** `content_map.json`, `content_sync.py`, `consistency_report.txt`

### pdf-processor
- **Prompt:** `agents/pdf-processor.md`
- **Custo:** Gratuito (modelo padrão)
- **Tarefas:**
  - Extrair texto e estrutura de PDFs
  - Mapear conteúdo PDF → HTML do site
  - Identificar assets referenciados
  - Validar fidelidade site vs PDF original
- **Saída:** `pdf-extract.json`

### seo-qa
- **Prompt:** `agents/seo-qa.md`
- **Custo:** Gratuito (modelo padrão)
- **Tarefas:**
  - Analisar SEO (meta tags, headings, alt text)
  - Verificar acessibilidade (contraste, aria labels)
  - Testar responsividade (Playwright)
  - Validar desempenho (assets, lazy loading)
- **Saída:** `qa-report.md`

## AGENTES DE INFRA E AUTOMAÇÃO

### build-assistant
- **Prompt:** `agents/build-assistant.md`
- **Custo:** Gratuito (modelo padrão)
- **Tarefas:**
  - Rastrear dependências entre arquivos
  - Detectar alterações e builds incrementais
  - Rodar lint/typecheck automático
  - Documentar cada execução
  - Testar builds completos
- **Saída:** `build_analysis.md`, `build_runner.py`, `build_plan.json`

### script-automation
- **Prompt:** `agents/script-automation.md`
- **Custo:** Gratuito (modelo padrão)
- **Tarefas:**
  - Criar scripts de build (Python/Batch/PowerShell)
  - Automatizar backup de assets + banco
  - Gerar scripts de deploy
  - Criar watchers para auto-build
- **Saída:** `build.bat/ps1`, `backup.py`, `deploy.py`, `watch.py`

### data-pipeline
- **Prompt:** `agents/data-pipeline.md`
- **Custo:** Gratuito (modelo padrão)
- **Tarefas:**
  - Extrair dados de CSV, JSON, Excel, PDF, HTML
  - Limpar e transformar (normalização, dedup, validação)
  - Carregar em SQLite
  - Gerar scripts ETL reutilizáveis
- **Ferramentas:** pandas, numpy, SQLite MCP
- **Saída:** Scripts `etl-*.py`, banco populado, relatórios

### db-agent
- **Prompt:** `agents/db-agent.md`
- **Custo:** Gratuito (modelo padrão)
- **Tarefas:**
  - Criar e gerenciar tabelas SQLite
  - Executar consultas SQL
  - Sincronizar dados entre arquivos e banco
  - Backup automático
- **Saída:** Tabelas e relatórios estruturados

## AGENTES DE LINGUAGEM

### go-dev
- **Prompt:** `agents/go-dev.md`
- **Custo:** Gratuito (modelo padrão)
- **Tarefas:**
  - Escrever código Go idiomático
  - Gerenciar módulos (go.mod, go.sum)
  - Executar testes/benchmarks/cobertura
  - Aplicar gofmt, go vet, gopls
  - Diagnosticar data races e concorrência

## AGENTES BUILT-IN (sempre disponíveis)

### general
- **Tipo:** Built-in
- **Tarefas:** Pesquisar perguntas complexas, tarefas multi-passo, processamento em lote

### customize-opencode
- **Tipo:** Built-in (skill)
- **Tarefas:** Editar configurações do OpenCode, gerenciar agentes/plugins/MCPs

## MCP Servers

| Nome | Comando | Função |
|------|---------|--------|
| puppeteer | `npx @anthropic/mcp-server-puppeteer --headless` | Navegação headless |
| playwright | `npx @anthropic/mcp-server-playwright` | Automação de navegador |
| github | `npx @anthropic/mcp-server-github` | Git/PRs/Issues |
| brave-search | `npx @anthropic/mcp-server-brave-search` | Busca web |
| sequential-thinking | `npx @modelcontextprotocol/server-sequential-thinking` | Raciocínio passo-a-passo |
| sqlite | `npx @modelcontextprotocol/server-sqlite <path>` | Banco de dados |
| memory | `npx @modelcontextprotocol/server-memory` | Memória persistente |
| filesystem | `npx @modelcontextprotocol/server-filesystem <path>` | Arquivos sandbox |

## Plugins

| Plugin | Função |
|--------|--------|
| `@op1/code-graph` | Grafo de dependências do código |
| `@op1/code-intel` | Inteligência de código avançada |

## Modelos

| Provedor | Modelo | Custo | Uso |
|----------|--------|-------|-----|
| `opencode` (Zen) | `deepseek-v4-flash` | Gratuito | Padrão - 99% dos casos |
| `opencode-go` | `qwen3.7-max` | Pago | Máximo poder |
| `opencode-go` | `qwen3.7-plus` | Pago | Muito potente |
| `opencode-go` | `deepseek-v4-pro` | Pago | Alternativa potente |
| `opencode-go` | `grok-4.5`, `kimi-k3`, `glm-5.2` | Pago | Especializados |

## Regras de Uso

1. **Sempre usar agentes primeiro** — analisar código com explore/web-dev antes de modificar
2. **Preferir ferramentas locais** — grep, glob, search antes de consumir créditos
3. **Modelo gratuito como padrão** — usar Go só quando o gratuito não resolver
4. **Agentes especializados** — cada tarefa tem o agente certo (web-dev, image-processor, etc.)
