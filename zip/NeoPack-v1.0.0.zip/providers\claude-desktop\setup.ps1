<#
.SYNOPSIS
    Claude Desktop - Setup Completo com MCPs
#>

$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Claude Desktop - Setup MCP" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$claudeConfigDir = "$env:APPDATA\Claude"
if (-not (Test-Path $claudeConfigDir)) {
    New-Item -ItemType Directory -Path $claudeConfigDir -Force | Out-Null
}

Write-Host "[1/3] Configurando MCP Servers..." -ForegroundColor Yellow

$mcpConfig = @{
    mcpServers = @{
        puppeteer = @{
            command = "npx"
            args = @("-y", "@anthropic/mcp-server-puppeteer", "--headless")
        }
        playwright = @{
            command = "npx"
            args = @("-y", "@anthropic/mcp-server-playwright")
        }
        github = @{
            command = "npx"
            args = @("-y", "@anthropic/mcp-server-github")
        }
        "brave-search" = @{
            command = "npx"
            args = @("-y", "@anthropic/mcp-server-brave-search")
        }
        "sequential-thinking" = @{
            command = "npx"
            args = @("-y", "@modelcontextprotocol/server-sequential-thinking")
        }
        sqlite = @{
            command = "npx"
            args = @("-y", "@modelcontextprotocol/server-sqlite")
        }
    }
}

$mcpConfig | ConvertTo-Json -Depth 10 | Set-Content "$claudeConfigDir\claude_desktop_config.json"
Write-Host "  ✓ MCPs configurados em $claudeConfigDir\claude_desktop_config.json" -ForegroundColor Green

Write-Host ""
Write-Host "[2/3] Instalando infraestrutura..." -ForegroundColor Yellow
npm install -g vscode-langservers-extracted 2>&1 | Out-Null
pip install ruff pandas numpy openpyxl 2>&1 | Out-Null
Write-Host "  ✓ LSPs e pacotes Python instalados" -ForegroundColor Green

Write-Host ""
Write-Host "[3/3] Instalando MCPs via npx..." -ForegroundColor Yellow
$mcps = @(
    "puppeteer", "playwright", "github", "brave-search",
    "sequential-thinking", "sqlite", "memory", "filesystem"
)
foreach ($mcp in $mcps) { 
    Write-Host "  Instalando $mcp..." -ForegroundColor Gray
    npx -y "@anthropic/mcp-server-$mcp" --version 2>&1 | Out-Null
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  SETUP CLAUDE DESKTOP CONCLUÍDO!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Próximos passos:" -ForegroundColor White
Write-Host "  1. Feche e reabra o Claude Desktop"
Write-Host "  2. Os MCPs estarão disponíveis automaticamente"
Write-Host "  3. Use os tools MCP nas suas conversas"
